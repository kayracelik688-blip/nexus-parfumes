import { products, formatPrice, type Product } from '../data/products';

interface FeaturedProps {
  onOpenProduct: (p: Product) => void;
  onViewAll: () => void;
}

export default function Featured({ onOpenProduct, onViewAll }: FeaturedProps) {
  const featured = products.filter((p) => p.featured).slice(0, 3);

  if (featured.length === 0) return null;

  return (
    <section className="relative section-pad bg-void border-t border-line" aria-labelledby="featured-title">
      <div className="container-page">
        <header className="mb-10 md:mb-14 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6">
          <div className="max-w-xl">
            <p className="eyebrow mb-4">Öne Çıkanlar</p>
            <h2 id="featured-title" className="section-title text-3xl sm:text-4xl md:text-[2.75rem]">
              İmza seçkisi
            </h2>
            <p className="section-lead mt-4">
              Koleksiyonun en çok tercih edilen parçaları — dengeli, kalıcı ve karakterli.
            </p>
          </div>
          <button type="button" onClick={onViewAll} className="btn-secondary self-start sm:self-auto">
            Tümünü Gör
          </button>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-line border border-line">
          {featured.map((product, index) => (
            <button
              key={product.id}
              type="button"
              onClick={() => onOpenProduct(product)}
              className="group relative bg-ink-soft text-left transition-colors duration-300 hover:bg-ink-elevated focus:outline-none"
            >
              <div className="relative aspect-[4/5] overflow-hidden img-frame">
                <img
                  src={product.image}
                  alt={product.name}
                  loading="lazy"
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-void via-void/20 to-transparent" />
                <div className="absolute top-4 left-4">
                  <span className="text-[0.5625rem] tracking-[0.22em] uppercase text-cream-muted">
                    0{index + 1}
                  </span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-6">
                  <p className="text-[0.5625rem] tracking-[0.18em] uppercase text-muted mb-2">
                    {product.category}
                  </p>
                  <h3 className="font-display text-2xl tracking-[0.06em] text-cream group-hover:text-cream-soft transition-colors">
                    {product.name}
                  </h3>
                  <p className="mt-2 text-[0.8125rem] font-light text-cream-muted line-clamp-2">
                    {product.shortDescription}
                  </p>
                  <div className="mt-4 flex items-center justify-between gap-3">
                    <span className="text-sm tracking-wide text-cream">
                      {formatPrice(product.price100)}
                      <span className="text-muted text-[0.6875rem] ml-1.5">/ 100 ml</span>
                    </span>
                    <span className="text-[0.625rem] tracking-[0.16em] uppercase text-cream-muted group-hover:text-gold transition-colors">
                      İncele →
                    </span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
