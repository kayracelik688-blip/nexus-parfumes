Gorselleri bu klasore koyun (oud-bottle.jpg, hero-bottle.jpg vb.)
