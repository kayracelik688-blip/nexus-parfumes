import type { Product } from '../data/products';
import type { FilterState } from '../components/Filters';

export function filterAndSortProducts(products: Product[], filters: FilterState): Product[] {
  const q = filters.search.trim().toLowerCase();

  let result = products.filter((p) => {
    if (filters.categories.length > 0 && !filters.categories.includes(p.category)) {
      return false;
    }
    if (filters.genders.length > 0 && !filters.genders.includes(p.gender)) {
      return false;
    }
    if (filters.types.length > 0 && !filters.types.includes(p.type)) {
      return false;
    }
    if (filters.seasons.length > 0) {
      const hit = filters.seasons.some(
        (s) => p.season.includes(s) || p.season.includes('Dört Mevsim')
      );
      if (!hit) return false;
    }
    if (filters.occasions.length > 0) {
      const hit = filters.occasions.some((o) => p.occasion.includes(o));
      if (!hit) return false;
    }
    // Price based on 100ml
    if (p.price100 < filters.priceMin || p.price100 > filters.priceMax) {
      return false;
    }
    if (q) {
      const hay = [
        p.name,
        p.brand,
        p.shortDescription,
        p.longDescription,
        p.category,
        p.type,
        p.gender,
        p.intensity,
        ...p.topNotes,
        ...p.heartNotes,
        ...p.baseNotes,
        ...p.season,
        ...p.occasion,
      ]
        .join(' ')
        .toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  result = [...result].sort((a, b) => {
    switch (filters.sort) {
      case 'price-asc':
        return a.price100 - b.price100;
      case 'price-desc':
        return b.price100 - a.price100;
      case 'name-asc':
        return a.name.localeCompare(b.name, 'tr');
      case 'name-desc':
        return b.name.localeCompare(a.name, 'tr');
      case 'featured':
      default:
        if (a.featured && !b.featured) return -1;
        if (!a.featured && b.featured) return 1;
        return a.name.localeCompare(b.name, 'tr');
    }
  });

  return result;
}
