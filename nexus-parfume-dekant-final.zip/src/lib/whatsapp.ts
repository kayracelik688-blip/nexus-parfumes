import { formatPrice, getProductById, getPriceForSize } from '../data/products';
import type { CartItem } from '../hooks/useCart';

/** NEXUS WhatsApp sipariş numarası — kendi numaranı buraya yaz */
export const WHATSAPP_NUMBER = '905551234567';

export function buildCartWhatsAppUrl(items: CartItem[]): string {
  const lines: string[] = ['Merhaba NEXUS 👋', '', 'Sipariş vermek istiyorum:', ''];

  items.forEach((item, idx) => {
    const p = getProductById(item.productId);
    if (!p) return;
    const unit = getPriceForSize(p, item.size);
    const lineTotal = unit * item.quantity;
    lines.push(
      `${idx + 1}) ${p.name} — ${item.size} ml${item.size < 100 ? ' Dekant' : ''} × ${item.quantity} = ${formatPrice(lineTotal)}`
    );
  });

  const total = items.reduce((sum, i) => {
    const p = getProductById(i.productId);
    if (!p) return sum;
    return sum + getPriceForSize(p, i.size) * i.quantity;
  }, 0);

  lines.push('', `Toplam: ${formatPrice(total)}`, '', 'Teşekkürler.');

  const text = encodeURIComponent(lines.join('\n'));
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${text}`;
}

export function buildProductWhatsAppUrl(
  productName: string,
  size: 100 | 2 | 4,
  price: number,
  quantity = 1
): string {
  const lines = [
    'Merhaba NEXUS 👋',
    '',
    'Bu ürünü sipariş etmek istiyorum:',
    `${productName} — ${size} ml${size < 100 ? ' Dekant' : ''} × ${quantity}`,
    `Fiyat: ${formatPrice(price * quantity)}`,
    '',
    'Teşekkürler.',
  ];
  const text = encodeURIComponent(lines.join('\n'));
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${text}`;
}
