import { useMemo } from 'react';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import {
  GENDERS,
  OCCASIONS,
  PRODUCT_TYPES,
  SCENT_FAMILIES,
  SEASONS,
  type Gender,
  type Occasion,
  type ProductType,
  type ScentFamily,
  type Season,
} from '../data/products';

export type SortOption = 'featured' | 'price-asc' | 'price-desc' | 'name-asc' | 'name-desc';

export interface FilterState {
  search: string;
  categories: ScentFamily[];
  genders: Gender[];
  seasons: Season[];
  occasions: Occasion[];
  types: ProductType[];
  priceMin: number;
  priceMax: number;
  sort: SortOption;
}

export const DEFAULT_FILTERS: FilterState = {
  search: '',
  categories: [],
  genders: [],
  seasons: [],
  occasions: [],
  types: [],
  priceMin: 0,
  priceMax: 3500,
  sort: 'featured',
};

export const PRICE_BOUNDS = { min: 0, max: 3500 };

interface FiltersProps {
  filters: FilterState;
  onChange: (next: FilterState) => void;
  resultCount: number;
  mobileOpen: boolean;
  onMobileOpenChange: (open: boolean) => void;
}

function toggleInArray<T>(arr: T[], value: T): T[] {
  return arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value];
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`px-3 py-1.5 text-[0.6875rem] tracking-[0.06em] border transition-colors duration-200 ${
        active
          ? 'border-cream/40 bg-cream/5 text-cream'
          : 'border-line text-cream-muted hover:border-line-strong hover:text-cream-soft'
      }`}
    >
      {children}
    </button>
  );
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <label className="text-[0.625rem] tracking-[0.2em] uppercase text-muted mb-2.5 block">
      {children}
    </label>
  );
}

function FilterBody({
  filters,
  onChange,
}: {
  filters: FilterState;
  onChange: (next: FilterState) => void;
}) {
  const set = (partial: Partial<FilterState>) => onChange({ ...filters, ...partial });

  return (
    <div className="space-y-7">
      <div>
        <FieldLabel>Arama</FieldLabel>
        <div className="relative">
          <Search
            className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted"
            strokeWidth={1.5}
          />
          <input
            type="search"
            value={filters.search}
            onChange={(e) => set({ search: e.target.value })}
            placeholder="Ürün, nota, koku..."
            className="w-full border border-line bg-ink-card pl-9 pr-3 py-2.5 text-sm font-light text-cream placeholder:text-muted focus:outline-none focus:border-line-strong transition-colors"
          />
        </div>
      </div>

      <div>
        <FieldLabel>Sıralama</FieldLabel>
        <select
          value={filters.sort}
          onChange={(e) => set({ sort: e.target.value as SortOption })}
          className="w-full border border-line bg-ink-card px-3 py-2.5 text-sm font-light text-cream focus:outline-none focus:border-line-strong transition-colors"
        >
          <option value="featured">Öne Çıkanlar</option>
          <option value="price-asc">Fiyat: Düşük → Yüksek</option>
          <option value="price-desc">Fiyat: Yüksek → Düşük</option>
          <option value="name-asc">İsim: A → Z</option>
          <option value="name-desc">İsim: Z → A</option>
        </select>
      </div>

      <div>
        <FieldLabel>Koku Ailesi</FieldLabel>
        <div className="flex flex-wrap gap-1.5">
          {SCENT_FAMILIES.map((c) => (
            <Chip
              key={c}
              active={filters.categories.includes(c)}
              onClick={() => set({ categories: toggleInArray(filters.categories, c) })}
            >
              {c}
            </Chip>
          ))}
        </div>
      </div>

      <div>
        <FieldLabel>Tür</FieldLabel>
        <div className="flex flex-wrap gap-1.5">
          {PRODUCT_TYPES.map((t) => (
            <Chip
              key={t}
              active={filters.types.includes(t)}
              onClick={() => set({ types: toggleInArray(filters.types, t) })}
            >
              {t}
            </Chip>
          ))}
        </div>
      </div>

      <div>
        <FieldLabel>Cinsiyet</FieldLabel>
        <div className="flex flex-wrap gap-1.5">
          {GENDERS.map((g) => (
            <Chip
              key={g}
              active={filters.genders.includes(g)}
              onClick={() => set({ genders: toggleInArray(filters.genders, g) })}
            >
              {g}
            </Chip>
          ))}
        </div>
      </div>

      <div>
        <FieldLabel>Mevsim</FieldLabel>
        <div className="flex flex-wrap gap-1.5">
          {SEASONS.map((s) => (
            <Chip
              key={s}
              active={filters.seasons.includes(s)}
              onClick={() => set({ seasons: toggleInArray(filters.seasons, s) })}
            >
              {s}
            </Chip>
          ))}
        </div>
      </div>

      <div>
        <FieldLabel>Kullanım</FieldLabel>
        <div className="flex flex-wrap gap-1.5">
          {OCCASIONS.map((o) => (
            <Chip
              key={o}
              active={filters.occasions.includes(o)}
              onClick={() => set({ occasions: toggleInArray(filters.occasions, o) })}
            >
              {o}
            </Chip>
          ))}
        </div>
      </div>

      <div>
        <FieldLabel>Fiyat (50 ml)</FieldLabel>
        <div className="space-y-3">
          <input
            type="range"
            min={PRICE_BOUNDS.min}
            max={PRICE_BOUNDS.max}
            step={50}
            value={filters.priceMax}
            onChange={(e) =>
              set({ priceMax: Math.max(Number(e.target.value), filters.priceMin + 50) })
            }
            className="w-full"
          />
          <div className="flex items-center gap-2">
            <input
              type="number"
              min={PRICE_BOUNDS.min}
              max={filters.priceMax}
              value={filters.priceMin}
              onChange={(e) =>
                set({
                  priceMin: Math.min(
                    Math.max(PRICE_BOUNDS.min, Number(e.target.value) || 0),
                    filters.priceMax - 50
                  ),
                })
              }
              className="w-full border border-line bg-ink-card px-2 py-2 text-sm font-light text-cream focus:outline-none focus:border-line-strong"
              aria-label="Minimum fiyat"
            />
            <span className="text-muted text-xs">—</span>
            <input
              type="number"
              min={filters.priceMin}
              max={PRICE_BOUNDS.max}
              value={filters.priceMax}
              onChange={(e) =>
                set({
                  priceMax: Math.max(
                    Math.min(PRICE_BOUNDS.max, Number(e.target.value) || PRICE_BOUNDS.max),
                    filters.priceMin + 50
                  ),
                })
              }
              className="w-full border border-line bg-ink-card px-2 py-2 text-sm font-light text-cream focus:outline-none focus:border-line-strong"
              aria-label="Maksimum fiyat"
            />
          </div>
        </div>
      </div>

      <button
        type="button"
        onClick={() => onChange({ ...DEFAULT_FILTERS })}
        className="w-full border border-line py-2.5 text-[0.6875rem] tracking-[0.16em] uppercase text-cream-muted hover:text-cream hover:border-line-strong transition-colors"
      >
        Filtreleri Temizle
      </button>
    </div>
  );
}

export default function Filters({
  filters,
  onChange,
  resultCount,
  mobileOpen,
  onMobileOpenChange,
}: FiltersProps) {
  const activeCount = useMemo(() => {
    let n = 0;
    if (filters.search.trim()) n++;
    n += filters.categories.length;
    n += filters.genders.length;
    n += filters.seasons.length;
    n += filters.occasions.length;
    n += filters.types.length;
    if (filters.priceMin > PRICE_BOUNDS.min || filters.priceMax < PRICE_BOUNDS.max) n++;
    if (filters.sort !== 'featured') n++;
    return n;
  }, [filters]);

  return (
    <>
      {/* Mobile trigger */}
      <div className="lg:hidden mb-6 flex items-center justify-between gap-3">
        <p className="text-[0.75rem] tracking-[0.12em] uppercase text-cream-muted">
          <span className="text-cream">{resultCount}</span> ürün
        </p>
        <button
          type="button"
          onClick={() => onMobileOpenChange(true)}
          className="inline-flex items-center gap-2 border border-line bg-ink-card px-4 py-2.5 text-[0.6875rem] tracking-[0.16em] uppercase text-cream hover:border-line-strong transition-colors"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" strokeWidth={1.5} />
          Filtrele
          {activeCount > 0 && (
            <span className="min-w-[18px] h-[18px] px-1 bg-cream text-void text-[10px] font-medium flex items-center justify-center">
              {activeCount}
            </span>
          )}
        </button>
      </div>

      {/* Desktop sidebar */}
      <aside className="hidden lg:block sticky top-28 self-start w-full max-h-[calc(100dvh-8rem)] overflow-y-auto overscroll-contain pr-1">
        <div className="border border-line bg-ink-soft/80 p-5 xl:p-6">
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-line">
            <h3 className="text-[0.6875rem] tracking-[0.22em] uppercase text-cream">Filtreler</h3>
            <span className="text-[0.6875rem] text-muted">{resultCount}</span>
          </div>
          <FilterBody filters={filters} onChange={onChange} />
        </div>
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[55] lg:hidden">
          <button
            type="button"
            className="absolute inset-0 bg-black/75"
            aria-label="Filtreleri kapat"
            onClick={() => onMobileOpenChange(false)}
          />
          <div className="absolute bottom-0 left-0 right-0 max-h-[88dvh] overflow-hidden border-t border-line bg-ink-soft shadow-2xl flex flex-col safe-pb">
            <div className="flex items-center justify-between px-5 py-4 border-b border-line shrink-0">
              <div className="flex items-center gap-2.5">
                <SlidersHorizontal className="w-4 h-4 text-cream-muted" strokeWidth={1.5} />
                <span className="text-[0.75rem] tracking-[0.2em] uppercase text-cream">
                  Filtreler
                </span>
                {activeCount > 0 && (
                  <span className="text-[0.6875rem] text-muted">({activeCount})</span>
                )}
              </div>
              <button
                type="button"
                onClick={() => onMobileOpenChange(false)}
                className="p-2 text-cream-muted hover:text-cream"
                aria-label="Kapat"
              >
                <X className="w-5 h-5" strokeWidth={1.5} />
              </button>
            </div>
            <div className="overflow-y-auto overscroll-contain p-5 flex-1">
              <FilterBody filters={filters} onChange={onChange} />
            </div>
            <div className="p-4 border-t border-line shrink-0">
              <button
                type="button"
                onClick={() => onMobileOpenChange(false)}
                className="btn-primary w-full"
              >
                {resultCount} ürünü göster
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
