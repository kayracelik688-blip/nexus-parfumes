import { useEffect, useState } from 'react';
import { Menu, ShoppingBag, X, Instagram, Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

const INSTAGRAM = 'https://www.instagram.com/nexus.parfume';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  onNavigate: (section: string) => void;
  activeSection?: string;
}

const NAV = [
  { id: 'koleksiyon', label: 'Koleksiyon' },
  { id: 'dekant', label: 'Dekant' },
  { id: 'aileler', label: 'Koku Aileleri' },
  { id: 'hakkimizda', label: 'Hakkımızda' },
  { id: 'iletisim', label: 'İletişim' },
];

export default function Header({
  cartCount,
  onOpenCart,
  onNavigate,
  activeSection = 'hero',
}: HeaderProps) {
  const { theme, toggleTheme } = useTheme();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileOpen]);

  const go = (id: string) => {
    setMobileOpen(false);
    onNavigate(id);
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-[background,border-color,backdrop-filter] duration-300 ${
          scrolled || mobileOpen
            ? 'bg-void/90 backdrop-blur-md border-b border-line'
            : 'bg-transparent border-b border-transparent'
        }`}
      >
        <div className="container-page">
          <div className="flex h-[4.25rem] md:h-[5rem] items-center justify-between gap-4">
            {/* Brand */}
            <button
              type="button"
              onClick={() => go('hero')}
              className="shrink-0 group flex flex-col items-start"
              aria-label="NEXUS ana sayfa"
            >
              <span className="font-display text-[1.65rem] md:text-[1.85rem] leading-none tracking-[0.32em] text-cream group-hover:text-cream-soft transition-colors duration-300 pl-[0.08em]">
                NEXUS
              </span>
              <span className="mt-1 text-[0.5625rem] tracking-[0.38em] uppercase text-muted font-light">
                Parfume
              </span>
            </button>

            {/* Desktop nav */}
            <nav className="hidden lg:flex items-center gap-10" aria-label="Ana menü">
              {NAV.map((item) => {
                const active = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => go(item.id)}
                    className={`relative text-[0.6875rem] tracking-[0.2em] uppercase transition-colors duration-250 py-1 ${
                      active ? 'text-cream' : 'text-cream-muted hover:text-cream'
                    }`}
                  >
                    {item.label}
                    <span
                      className={`absolute left-0 -bottom-0.5 h-px bg-gold transition-all duration-300 ${
                        active ? 'w-full opacity-100' : 'w-0 opacity-0'
                      }`}
                    />
                  </button>
                );
              })}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-0.5 sm:gap-1">
              <button
                type="button"
                onClick={toggleTheme}
                className="p-2.5 text-cream-muted hover:text-cream transition-colors duration-200"
                aria-label={theme === 'dark' ? 'Açık temaya geç' : 'Koyu temaya geç'}
              >
                {theme === 'dark' ? (
                  <Sun className="w-[18px] h-[18px]" strokeWidth={1.5} />
                ) : (
                  <Moon className="w-[18px] h-[18px]" strokeWidth={1.5} />
                )}
              </button>
              <a
                href={INSTAGRAM}
                target="_blank"
                rel="noopener noreferrer"
                className="hidden sm:inline-flex p-2.5 text-cream-muted hover:text-cream transition-colors duration-200"
                aria-label="Instagram"
              >
                <Instagram className="w-[18px] h-[18px]" strokeWidth={1.5} />
              </a>

              <button
                type="button"
                onClick={onOpenCart}
                className="relative p-2.5 text-cream-muted hover:text-cream transition-colors duration-200"
                aria-label="Sepet"
              >
                <ShoppingBag className="w-[18px] h-[18px]" strokeWidth={1.5} />
                {cartCount > 0 && (
                  <span className="absolute top-1 right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-cream text-void text-[9px] font-medium flex items-center justify-center leading-none">
                    {cartCount > 99 ? '99+' : cartCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                className="lg:hidden p-2.5 text-cream-muted hover:text-cream transition-colors duration-200"
                onClick={() => setMobileOpen((v) => !v)}
                aria-label={mobileOpen ? 'Menüyü kapat' : 'Menüyü aç'}
                aria-expanded={mobileOpen}
              >
                {mobileOpen ? (
                  <X className="w-5 h-5" strokeWidth={1.5} />
                ) : (
                  <Menu className="w-5 h-5" strokeWidth={1.5} />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <div
        className={`fixed inset-0 z-40 lg:hidden transition-opacity duration-300 ${
          mobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <button
          type="button"
          className="absolute inset-0 bg-black/70"
          aria-label="Menüyü kapat"
          onClick={() => setMobileOpen(false)}
        />
        <nav
          className={`absolute top-0 right-0 h-full w-[min(100%,20rem)] bg-ink border-l border-line flex flex-col pt-[5.5rem] px-7 safe-pb transition-transform duration-300 ease-out ${
            mobileOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
          aria-label="Mobil menü"
        >
          <div className="flex flex-col">
            {NAV.map((item) => {
              const active = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => go(item.id)}
                  className={`text-left py-4 border-b border-line font-display text-[1.5rem] tracking-[0.12em] transition-colors ${
                    active ? 'text-cream' : 'text-cream-muted hover:text-cream'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
          <div className="mt-auto pt-8">
            <a
              href={INSTAGRAM}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 text-[0.75rem] tracking-[0.14em] uppercase text-cream-muted hover:text-cream transition-colors"
            >
              <Instagram className="w-4 h-4" strokeWidth={1.5} />
              @nexus.parfume
            </a>
          </div>
        </nav>
      </div>
    </>
  );
}
