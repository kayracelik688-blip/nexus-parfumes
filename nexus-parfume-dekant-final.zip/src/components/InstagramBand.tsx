import { Instagram, ArrowUpRight } from 'lucide-react';

const INSTAGRAM = 'https://www.instagram.com/nexus.parfume';

export default function InstagramBand() {
  return (
    <section className="border-t border-line bg-void" aria-label="Instagram">
      <div className="container-page py-12 md:py-14">
        <a
          href={INSTAGRAM}
          target="_blank"
          rel="noopener noreferrer"
          className="group flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6 border border-line bg-ink-soft px-6 py-7 sm:px-8 sm:py-8 transition-colors duration-300 hover:border-line-strong hover:bg-ink-elevated"
        >
          <div className="flex items-start sm:items-center gap-4">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center border border-line text-cream-muted group-hover:text-cream transition-colors">
              <Instagram className="w-5 h-5" strokeWidth={1.5} />
            </span>
            <div>
              <p className="text-[0.625rem] tracking-[0.24em] uppercase text-muted mb-1.5">
                Sosyal
              </p>
              <p className="font-display text-2xl sm:text-3xl tracking-[0.08em] text-cream">
                @nexus.parfume
              </p>
              <p className="mt-1.5 text-[0.875rem] font-light text-cream-muted">
                Yeni formüller ve koleksiyon paylaşımları
              </p>
            </div>
          </div>
          <span className="inline-flex items-center gap-2 text-[0.6875rem] tracking-[0.18em] uppercase text-cream-muted group-hover:text-gold transition-colors self-start sm:self-center">
            Takip Et
            <ArrowUpRight className="w-4 h-4" strokeWidth={1.5} />
          </span>
        </a>
      </div>
    </section>
  );
}
