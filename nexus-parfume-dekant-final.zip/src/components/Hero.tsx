interface HeroProps {
  onExplore: (family?: string) => void;
}

export default function Hero({ onExplore }: HeroProps) {
  return (
    <section
      id="hero"
      className="relative min-h-[100dvh] flex items-stretch overflow-hidden bg-void"
    >
      {/* Ambient wash — very subtle */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_70%_40%,rgba(212,180,90,0.10),transparent_55%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_20%_80%,rgba(255,255,255,0.03),transparent_45%)]" />
      </div>

      <div className="container-page relative z-10 w-full flex items-center pt-28 pb-20 md:pt-32 md:pb-24">
        <div className="grid w-full lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          {/* Copy */}
          <div className="lg:col-span-6 xl:col-span-5 order-2 lg:order-1">
            <p className="eyebrow mb-6 md:mb-8">Niş Parfüm Koleksiyonu</p>

            <h1 className="font-display text-[2.75rem] sm:text-5xl md:text-6xl xl:text-[4.25rem] leading-[1.05] tracking-[0.02em] text-cream font-normal">
              Kokunun
              <br />
              <span className="italic font-normal text-cream-soft">kesişim</span> noktası
            </h1>

            <div className="mt-6 md:mt-8 h-px w-12 bg-gold" />

            <p className="mt-6 md:mt-8 max-w-md text-[0.9375rem] md:text-base font-light leading-[1.75] text-cream-muted">
              Orijinal imzalar ve Arap esintili seçkiler. Oud’dan ambere, deriden miske —
              her formül özenle dengelenmiş bir karakter taşır.
            </p>

            <div className="mt-8 md:mt-10 flex flex-col sm:flex-row sm:flex-wrap gap-3">
              <button type="button" onClick={() => onExplore()} className="btn-primary w-full sm:w-auto">
                Koleksiyonu Keşfet
              </button>
              <button
                type="button"
                onClick={() => onExplore('Oud')}
                className="btn-secondary w-full sm:w-auto"
              >
                Oud Keşfet
              </button>
              <button
                type="button"
                onClick={() => onExplore('Amber')}
                className="btn-secondary w-full sm:w-auto"
              >
                Amber Keşfet
              </button>
            </div>

            {/* Quiet trust line */}
            <div className="mt-10 md:mt-12 flex flex-wrap items-center gap-x-6 gap-y-2 text-[0.6875rem] tracking-[0.14em] uppercase text-muted">
              <span>50 & 100 ml</span>
              <span className="hidden sm:inline text-line-strong">|</span>
              <span>WhatsApp sipariş</span>
              <span className="hidden sm:inline text-line-strong">|</span>
              <span>8 koku ailesi</span>
            </div>
          </div>

          {/* Visual */}
          <div className="lg:col-span-6 xl:col-span-7 order-1 lg:order-2">
            <div className="relative mx-auto w-full max-w-[28rem] lg:max-w-none">
              <div className="relative aspect-[4/5] sm:aspect-[5/6] lg:aspect-[4/5] xl:aspect-[5/6] overflow-hidden img-frame border border-line bg-[#f5f3ee]">
                <img
                  src="/images/perfume-khamrah-qahwa.jpg"
                  alt="Lattafa Khamrah Qahwa"
                  className="absolute inset-0 h-full w-full object-contain object-center p-4 sm:p-6"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-void/75 via-transparent to-transparent pointer-events-none" />
                <div className="absolute inset-0 bg-gradient-to-r from-void/30 via-transparent to-transparent lg:from-void/40 pointer-events-none" />

                {/* Caption */}
                <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-7">
                  <p className="text-[0.625rem] tracking-[0.28em] uppercase text-cream-muted mb-1.5">
                    Öne Çıkan
                  </p>
                  <p className="font-display text-2xl sm:text-3xl tracking-[0.08em] text-cream">
                    Khamrah Qahwa
                  </p>
                </div>
              </div>

              {/* Thin decorative frame offset — desktop only */}
              <div
                className="pointer-events-none absolute -inset-3 border border-line-soft hidden lg:block"
                aria-hidden
              />
            </div>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div className="pointer-events-none absolute bottom-6 left-1/2 -translate-x-1/2 hidden md:flex flex-col items-center gap-2">
        <span className="text-[0.5625rem] tracking-[0.28em] uppercase text-muted">Kaydır</span>
        <span className="block h-8 w-px bg-gradient-to-b from-gold/60 to-transparent" />
      </div>

      {/* Bottom edge */}
      <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-px bg-line" />
    </section>
  );
}
