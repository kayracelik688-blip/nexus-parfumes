import { motion } from 'framer-motion';
import { Droplets } from 'lucide-react';
import { products, formatPrice, getPriceForSize, type Product } from '../data/products';

interface DecantProps {
  onOpenProduct: (product: Product, size?: 2 | 4 | 100) => void;
}

export default function Decant({ onOpenProduct }: DecantProps) {
  return (
    <section id="dekant" className="section-pad border-t border-line/60 bg-ink-soft/40">
      <div className="container-page">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.55 }}
          className="mb-8 md:mb-12 flex items-end justify-between gap-5"
        >
          <div>
            <p className="eyebrow mb-3">KÜÇÜK ŞİŞE, BÜYÜK KOKU</p>
            <h2 className="heading-section">Dekant</h2>
            <p className="mt-3 max-w-xl text-sm font-light leading-relaxed text-cream-muted">
              Favori kokularını önce küçük boyutta keşfet. 2 ml ve 4 ml seçenekleriyle
              koleksiyondan dilediğini dene.
            </p>
          </div>
          <Droplets className="hidden sm:block w-8 h-8 text-gold/70" strokeWidth={1.2} />
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-3 gap-y-8 sm:gap-x-5 sm:gap-y-10">
          {products.map((product, index) => (
            <motion.article
              key={product.id}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-30px' }}
              transition={{ duration: 0.45, delay: Math.min(index * 0.035, 0.2) }}
              className="group"
            >
              <button
                type="button"
                onClick={() => onOpenProduct(product, 2)}
                className="w-full text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-gold/50"
              >
                <div className="relative aspect-[3/4] overflow-hidden img-frame border border-line group-hover:border-gold/40 transition-colors duration-300 bg-[#f5f3ee]">
                  <img
                    src={product.image}
                    alt={`${product.brand} ${product.name} dekant`}
                    loading="lazy"
                    decoding="async"
                    className="absolute inset-0 h-full w-full object-contain object-center p-3 sm:p-4 transition-transform duration-500 group-hover:scale-[1.035]"
                    onError={(e) => { e.currentTarget.src = '/images/hero-bottle.jpg'; }}
                  />
                  <span className="absolute top-2 left-2 sm:top-3 sm:left-3 bg-void/75 backdrop-blur-sm border border-gold/30 px-2 py-1 text-[0.48rem] sm:text-[0.55rem] tracking-[0.15em] uppercase text-gold">
                    Dekant
                  </span>
                  <div className="absolute inset-x-0 bottom-0 p-2 sm:p-3">
                    <span className="flex items-center justify-center min-h-[32px] border border-cream/25 bg-void/75 backdrop-blur-sm text-[0.52rem] sm:text-[0.6rem] tracking-[0.15em] uppercase text-cream">
                      2 ml · 4 ml İncele
                    </span>
                  </div>
                </div>

                <div className="pt-3 px-0.5">
                  <p className="text-[0.5rem] sm:text-[0.6rem] tracking-[0.14em] uppercase text-muted truncate">
                    {product.brand}
                  </p>
                  <h3 className="mt-1 font-display text-[0.95rem] sm:text-[1.15rem] tracking-[0.03em] text-cream line-clamp-2">
                    {product.name}
                  </h3>
                  <div className="mt-2 flex items-center justify-between gap-2">
                    <span className="text-[0.58rem] sm:text-[0.65rem] uppercase tracking-[0.12em] text-muted">
                      2 ml'den
                    </span>
                    <span className="text-[0.75rem] sm:text-[0.9rem] font-medium text-cream">
                      {formatPrice(getPriceForSize(product, 2))}
                    </span>
                  </div>
                </div>
              </button>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
