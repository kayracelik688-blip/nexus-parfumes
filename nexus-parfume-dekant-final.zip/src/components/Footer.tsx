import { Instagram } from 'lucide-react';
import { SCENT_FAMILIES, type ScentFamily } from '../data/products';

const INSTAGRAM = 'https://www.instagram.com/nexus.parfume';

interface FooterProps {
  onFamilyClick: (family: ScentFamily) => void;
  onNavigate: (section: string) => void;
}

export default function Footer({ onFamilyClick, onNavigate }: FooterProps) {
  return (
    <footer id="iletisim" className="border-t border-line bg-void">
      <div className="container-page py-14 md:py-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-4">
            <button
              type="button"
              onClick={() => onNavigate('hero')}
              className="text-left group"
            >
              <span className="font-display text-2xl tracking-[0.28em] text-cream group-hover:text-cream-soft transition-colors">
                NEXUS
              </span>
              <span className="block mt-1.5 text-[0.5625rem] tracking-[0.32em] uppercase text-muted">
                Parfume
              </span>
            </button>
            <p className="mt-5 max-w-xs text-[0.875rem] font-light leading-relaxed text-cream-muted">
              Niş parfüm seçkisi. Orijinal imzalar ve Arap esintili formüller.
            </p>
            <a
              href={INSTAGRAM}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 inline-flex items-center gap-2.5 text-[0.75rem] tracking-[0.12em] uppercase text-cream-muted hover:text-cream transition-colors"
            >
              <Instagram className="w-4 h-4" strokeWidth={1.5} />
              @nexus.parfume
            </a>
          </div>

          {/* Explore */}
          <div className="lg:col-span-2">
            <h4 className="text-[0.625rem] tracking-[0.24em] uppercase text-muted mb-5">
              Keşfet
            </h4>
            <ul className="space-y-3">
              {[
                { id: 'koleksiyon', label: 'Koleksiyon' },
                { id: 'aileler', label: 'Koku Aileleri' },
                { id: 'hakkimizda', label: 'Hakkımızda' },
              ].map((l) => (
                <li key={l.id}>
                  <button
                    type="button"
                    onClick={() => onNavigate(l.id)}
                    className="text-[0.875rem] font-light text-cream-muted hover:text-cream transition-colors"
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Families */}
          <div className="lg:col-span-3">
            <h4 className="text-[0.625rem] tracking-[0.24em] uppercase text-muted mb-5">
              Koku Aileleri
            </h4>
            <ul className="grid grid-cols-2 gap-x-4 gap-y-3">
              {SCENT_FAMILIES.map((f) => (
                <li key={f}>
                  <button
                    type="button"
                    onClick={() => onFamilyClick(f)}
                    className="text-[0.875rem] font-light text-cream-muted hover:text-cream transition-colors"
                  >
                    {f}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="lg:col-span-3">
            <h4 className="text-[0.625rem] tracking-[0.24em] uppercase text-muted mb-5">
              İletişim
            </h4>
            <ul className="space-y-3 text-[0.875rem] font-light text-cream-muted">
              <li>
                <a
                  href={INSTAGRAM}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-cream transition-colors"
                >
                  Instagram
                </a>
              </li>
              <li>
                <a
                  href="https://wa.me/905551234567"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-cream transition-colors"
                >
                  WhatsApp sipariş
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 pt-6 border-t border-line flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <p className="text-[0.6875rem] tracking-wide text-muted">
            © {new Date().getFullYear()} NEXUS. Tüm hakları saklıdır.
          </p>
          <p className="text-[0.6875rem] tracking-[0.18em] uppercase text-muted">
            nexus.parfume
          </p>
        </div>
      </div>
    </footer>
  );
}
