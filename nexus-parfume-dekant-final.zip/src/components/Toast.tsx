import { useEffect } from 'react';
import { Check } from 'lucide-react';

interface ToastProps {
  message: string | null;
  onDismiss: () => void;
}

export default function Toast({ message, onDismiss }: ToastProps) {
  useEffect(() => {
    if (!message) return;
    const t = window.setTimeout(onDismiss, 2600);
    return () => window.clearTimeout(t);
  }, [message, onDismiss]);

  if (!message) return null;

  return (
    <div
      className="fixed bottom-6 left-1/2 z-[80] -translate-x-1/2 px-4 w-full max-w-sm pointer-events-none safe-pb"
      role="status"
      aria-live="polite"
    >
      <div className="pointer-events-auto flex items-center gap-3 border border-line bg-ink-elevated/95 backdrop-blur-md px-4 py-3.5 shadow-[0_12px_40px_rgba(0,0,0,0.45)] animate-toast-in">
        <span className="flex h-7 w-7 shrink-0 items-center justify-center border border-line text-gold">
          <Check className="w-3.5 h-3.5" strokeWidth={1.75} />
        </span>
        <p className="text-[0.8125rem] font-light tracking-wide text-cream-soft">{message}</p>
      </div>
    </div>
  );
}
