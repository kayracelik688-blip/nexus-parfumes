import { useEffect, useState } from 'react';
import { ArrowUp } from 'lucide-react';

export default function BackToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <button
      type="button"
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      aria-label="Yukarı çık"
      className={`fixed bottom-5 right-4 sm:bottom-7 sm:right-6 z-40 flex h-11 w-11 items-center justify-center border border-line bg-ink-elevated/90 text-cream-muted backdrop-blur-sm transition-all duration-300 hover:border-line-strong hover:text-cream ${
        visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3 pointer-events-none'
      }`}
    >
      <ArrowUp className="w-4 h-4" strokeWidth={1.5} />
    </button>
  );
}
