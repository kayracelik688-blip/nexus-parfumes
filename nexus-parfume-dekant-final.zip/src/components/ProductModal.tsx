import { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Minus, Plus, ShoppingBag, X, MessageCircle } from 'lucide-react';
import type { Product } from '../data/products';
import { formatPrice, getPriceForSize } from '../data/products';
import type { BottleSize } from '../hooks/useCart';
import { buildProductWhatsAppUrl } from '../lib/whatsapp';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (productId: string, size: BottleSize, quantity: number) => void;
  initialSize?: BottleSize;
}

export default function ProductModal({ product, onClose, onAddToCart, initialSize = 100 }: ProductModalProps) {
  const [size, setSize] = useState<BottleSize>(100);
  const [qty, setQty] = useState(1);
  const isDecant = initialSize === 2 || initialSize === 4;

  useEffect(() => {
    if (product) {
      setSize(initialSize);
      setQty(1);
    }
  }, [product?.id, initialSize]);

  useEffect(() => {
    if (!product) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
  }, [product, onClose]);

  const unitPrice = useMemo(() => {
    if (!product) return 0;
    return getPriceForSize(product, size);
  }, [product, size]);

  const lineTotal = unitPrice * qty;

  const whatsappUrl = useMemo(() => {
    if (!product) return '#';
    return buildProductWhatsAppUrl(product.name, size, unitPrice, qty);
  }, [product, size, unitPrice, qty]);

  return (
    <AnimatePresence>
      {product && (
        <div
          className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-5"
          role="dialog"
          aria-modal="true"
          aria-labelledby="product-modal-title"
        >
          {/* Blurred backdrop */}
          <motion.button
            type="button"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="absolute inset-0 bg-black/75 backdrop-blur-xl"
            aria-label="Kapat"
            onClick={onClose}
          />

          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.98 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="relative w-full sm:max-w-3xl max-h-[92dvh] sm:max-h-[90vh] overflow-hidden border border-line bg-ink-soft shadow-2xl flex flex-col sm:rounded-sm"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 sm:px-6 py-3.5 border-b border-line shrink-0">
              <span className="text-[0.625rem] tracking-[0.24em] uppercase text-muted">
                Ürün Detayı
              </span>
              <button
                type="button"
                onClick={onClose}
                className="p-2 text-cream-muted hover:text-cream transition-colors"
                aria-label="Kapat"
              >
                <X className="w-5 h-5" strokeWidth={1.5} />
              </button>
            </div>

            <div className="overflow-y-auto flex-1 overscroll-contain">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-0">
                {/* Image */}
                <div className="relative aspect-[4/5] sm:aspect-auto sm:min-h-[420px] bg-[#f5f3ee] overflow-hidden flex items-center justify-center">
                  <img
                    src={product.image}
                    alt={`${product.brand} ${product.name}`}
                    className="absolute inset-0 h-full w-full object-contain object-center p-4 sm:p-6"
                    onError={(e) => {
                      e.currentTarget.src = '/images/hero-bottle.jpg';
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-soft/40 via-transparent to-transparent sm:hidden" />
                </div>

                {/* Content */}
                <div className="flex flex-col p-5 sm:p-7">
                  <p className="text-[0.625rem] tracking-[0.2em] uppercase text-muted mb-2">
                    {product.brand}
                    <span className="mx-1.5 text-line-strong">·</span>
                    {product.category}
                    <span className="mx-1.5 text-line-strong">·</span>
                    {product.gender}
                  </p>

                  <h2
                    id="product-modal-title"
                    className="font-display text-2xl sm:text-3xl tracking-[0.04em] text-cream leading-tight"
                  >
                    {product.name}
                  </h2>

                  <p className="mt-3 text-sm font-light leading-relaxed text-cream-muted">
                    {product.shortDescription}
                  </p>

                  <p className="mt-4 text-[0.8125rem] font-light leading-relaxed text-cream-muted/90 line-clamp-4">
                    {product.longDescription}
                  </p>

                  {/* Notes */}
                  <div className="mt-5 grid grid-cols-3 gap-3 text-[0.6875rem]">
                    <div>
                      <p className="tracking-[0.14em] uppercase text-muted mb-1.5">Üst</p>
                      <p className="text-cream-soft leading-snug">{product.topNotes.join(', ')}</p>
                    </div>
                    <div>
                      <p className="tracking-[0.14em] uppercase text-muted mb-1.5">Kalp</p>
                      <p className="text-cream-soft leading-snug">{product.heartNotes.join(', ')}</p>
                    </div>
                    <div>
                      <p className="tracking-[0.14em] uppercase text-muted mb-1.5">Dip</p>
                      <p className="text-cream-soft leading-snug">{product.baseNotes.join(', ')}</p>
                    </div>
                  </div>

                  {/* Size / Decant */}
                  <div className="mt-6">
                    <p className="text-[0.625rem] tracking-[0.16em] uppercase text-muted mb-2.5">
                      Boyut
                    </p>
                    <div className={`grid ${isDecant ? 'grid-cols-2' : 'grid-cols-3'} gap-2`}>
                      {(isDecant ? ([2, 4] as BottleSize[]) : ([100, 2, 4] as BottleSize[])).map((option) => (
                        <button
                          key={option}
                          type="button"
                          onClick={() => setSize(option)}
                          className={`min-h-[52px] border px-3 text-left transition-all duration-200 ${
                            size === option
                              ? 'border-gold/60 bg-gold/10'
                              : 'border-line bg-ink-card hover:border-line-strong'
                          }`}
                        >
                          <span className={`block text-[0.75rem] tracking-wide ${size === option ? 'text-gold' : 'text-cream'}`}>
                            {option === 100 ? '100 ml' : `${option} ml Dekant`}
                          </span>
                          <span className="mt-1 block text-[0.75rem] font-medium text-cream tabular-nums">
                            {formatPrice(getPriceForSize(product, option))}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Qty */}
                  <div className="mt-5 flex items-center gap-4">
                    <p className="text-[0.625rem] tracking-[0.16em] uppercase text-muted">Adet</p>
                    <div className="flex items-center border border-line">
                      <button
                        type="button"
                        onClick={() => setQty((q) => Math.max(1, q - 1))}
                        className="p-2.5 text-cream-muted hover:text-cream transition-colors"
                        aria-label="Azalt"
                      >
                        <Minus className="w-4 h-4" strokeWidth={1.5} />
                      </button>
                      <span className="w-10 text-center text-sm text-cream tabular-nums">{qty}</span>
                      <button
                        type="button"
                        onClick={() => setQty((q) => Math.min(10, q + 1))}
                        className="p-2.5 text-cream-muted hover:text-cream transition-colors"
                        aria-label="Artır"
                      >
                        <Plus className="w-4 h-4" strokeWidth={1.5} />
                      </button>
                    </div>
                    <span className="ml-auto text-sm font-medium text-cream tabular-nums">
                      {formatPrice(lineTotal)}
                    </span>
                  </div>

                  {/* Actions */}
                  <div className="mt-6 flex flex-col sm:flex-row gap-2.5">
                    <button
                      type="button"
                      onClick={() => {
                        onAddToCart(product.id, size, qty);
                        onClose();
                      }}
                      className="btn-primary flex-1 gap-2"
                    >
                      <ShoppingBag className="w-4 h-4" strokeWidth={1.5} />
                      Sepete Ekle
                    </button>
                    <a
                      href={whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-secondary flex-1 gap-2 justify-center"
                    >
                      <MessageCircle className="w-4 h-4" strokeWidth={1.5} />
                      WhatsApp
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
