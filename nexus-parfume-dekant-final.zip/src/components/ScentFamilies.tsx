import { ArrowUpRight } from 'lucide-react';
import { SCENT_FAMILIES, type ScentFamily } from '../data/products';

const FAMILY_META: Record<ScentFamily, string> = {
  Amber: 'Sıcak, reçineli ve sarmalayıcı',
  Oud: 'Derin, odunsu ve mistik',
  Odunsu: 'Sedir, sandal ve orman izi',
  Çiçeksi: 'Gül, yasemin ve zarif çiçekler',
  Fresh: 'Narenciye, deniz ve ferahlık',
  Baharatlı: 'Karabiber, safran ve sıcak baharat',
  Misk: 'Temiz, yumuşak ve cilde yakın',
  Deri: 'Dumanlı, koyu ve karakterli',
};

interface ScentFamiliesProps {
  onSelect: (family: ScentFamily) => void;
}

export default function ScentFamilies({ onSelect }: ScentFamiliesProps) {
  return (
    <section id="aileler" className="relative section-pad bg-void border-t border-line">
      <div className="container-page">
        <header className="mb-10 md:mb-14 max-w-xl">
          <p className="eyebrow mb-4">Koku Aileleri</p>
          <h2 className="section-title text-3xl sm:text-4xl md:text-[2.75rem]">
            Ailene göre keşfet
          </h2>
          <p className="section-lead mt-4">
            Bir aile seçin; koleksiyonda ilgili filtre otomatik uygulanır.
          </p>
        </header>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-line border border-line">
          {SCENT_FAMILIES.map((family) => (
            <button
              key={family}
              type="button"
              onClick={() => onSelect(family)}
              className="group relative bg-ink-soft p-5 sm:p-6 md:p-7 text-left min-h-[9.5rem] sm:min-h-[10.5rem] flex flex-col transition-colors duration-300 hover:bg-ink-elevated"
            >
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-display text-xl sm:text-2xl tracking-[0.06em] text-cream group-hover:text-cream-soft transition-colors">
                  {family}
                </h3>
                <ArrowUpRight
                  className="w-4 h-4 text-muted group-hover:text-gold transition-colors shrink-0 mt-1"
                  strokeWidth={1.5}
                />
              </div>
              <p className="mt-auto pt-6 text-[0.8125rem] font-light leading-relaxed text-cream-muted">
                {FAMILY_META[family]}
              </p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
