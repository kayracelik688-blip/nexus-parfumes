const STEPS = [
  {
    n: '01',
    title: 'Keşfet',
    text: 'Koku ailesi, mevsim ve türe göre filtreleyerek size uygun formülü bulun.',
  },
  {
    n: '02',
    title: 'Seç',
    text: '50 ml veya 100 ml boyutunu belirleyin, sepete ekleyin.',
  },
  {
    n: '03',
    title: 'Sipariş',
    text: 'WhatsApp üzerinden siparişinizi iletin; yönlendirme ile tamamlayın.',
  },
];

export default function OrderSteps() {
  return (
    <section className="relative border-t border-line bg-ink" aria-label="Sipariş adımları">
      <div className="container-page py-14 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-0 md:divide-x md:divide-line">
          {STEPS.map((step) => (
            <div key={step.n} className="md:px-8 first:md:pl-0 last:md:pr-0">
              <p className="text-[0.625rem] tracking-[0.28em] uppercase text-gold mb-3">
                {step.n}
              </p>
              <h3 className="font-display text-2xl tracking-[0.06em] text-cream mb-3">
                {step.title}
              </h3>
              <p className="text-[0.875rem] font-light leading-relaxed text-cream-muted max-w-xs">
                {step.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
