import { useCallback, useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence, useMotionValue } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { products, formatPrice, type Product } from '../data/products';

interface DailyPerfumeProps {
  onOpenProduct: (p: Product) => void;
  onViewAll: () => void;
}

const AUTO_MS = 3500;

export default function DailyPerfume({ onOpenProduct, onViewAll }: DailyPerfumeProps) {
  const featured = products.filter((p) => p.featured);
  const list = featured.length > 0 ? featured : products.slice(0, 4);
  const n = list.length;

  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const dragX = useMotionValue(0);
  const resumeTimer = useRef<number | null>(null);
  const autoToken = useRef(0);

  const go = useCallback((dir: number) => setIndex((i) => (i + dir + n) % n), [n]);
  const goTo = useCallback((i: number) => setIndex(((i % n) + n) % n), [n]);

  const bumpManual = useCallback(() => {
    setPaused(true);
    autoToken.current += 1;
    if (resumeTimer.current) window.clearTimeout(resumeTimer.current);
    resumeTimer.current = window.setTimeout(() => setPaused(false), AUTO_MS);
  }, []);

  useEffect(() => {
    if (paused || n <= 1) return;
    const token = autoToken.current;
    const t = window.setInterval(() => {
      if (autoToken.current !== token) return;
      setIndex((i) => (i + 1) % n);
    }, AUTO_MS);
    return () => clearInterval(t);
  }, [paused, n, index]);

  useEffect(
    () => () => {
      if (resumeTimer.current) window.clearTimeout(resumeTimer.current);
    },
    []
  );

  if (n === 0) return null;
  const active = list[index];

  return (
    <section
      id="gunun-parfumu"
      className="relative section-pad overflow-hidden border-t border-gold/25 bg-ink"
      aria-labelledby="daily-title"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onTouchStart={() => setPaused(true)}
      onTouchEnd={() => bumpManual()}
    >
      {/* Sarı vurgu arka plan */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_30%_50%,rgba(212,180,90,0.08),transparent_60%)]" />

      <div className="container-page relative z-10">
        <motion.header
          className="mb-10 md:mb-14 max-w-xl"
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-12%' }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        >
          <p className="text-[0.6875rem] tracking-[0.28em] uppercase text-gold mb-4">Özel seçim</p>
          <h2 id="daily-title" className="section-title text-3xl sm:text-4xl md:text-[2.75rem] text-cream">
            Günün <span className="text-gold italic">parfümü</span>
          </h2>
          <div className="mt-5 h-px w-16 bg-gold" />
        </motion.header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/5] overflow-hidden border border-gold/30 bg-[#f5f3ee] select-none">
              <AnimatePresence mode="wait">
                <motion.img
                  key={active.id}
                  src={active.image}
                  alt={`${active.brand} ${active.name}`}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                  className="absolute inset-0 h-full w-full object-contain object-center p-6 sm:p-10 cursor-grab active:cursor-grabbing"
                  drag="x"
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={0.14}
                  style={{ x: dragX }}
                  onDragStart={() => setPaused(true)}
                  onDragEnd={(_, info) => {
                    if (info.offset.x < -50 || info.velocity.x < -200) {
                      go(1);
                      bumpManual();
                    } else if (info.offset.x > 50 || info.velocity.x > 200) {
                      go(-1);
                      bumpManual();
                    } else bumpManual();
                  }}
                  onClick={() => onOpenProduct(active)}
                  draggable={false}
                />
              </AnimatePresence>
              <div className="absolute top-0 left-0 right-0 h-0.5 bg-gold" />
            </div>

            {n > 1 && (
              <div className="mt-4 flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => {
                    go(-1);
                    bumpManual();
                  }}
                  className="w-10 h-10 flex items-center justify-center border border-gold/40 text-gold hover:bg-gold hover:text-void transition-colors"
                  aria-label="Önceki"
                >
                  <ChevronLeft className="w-5 h-5" strokeWidth={1.5} />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    go(1);
                    bumpManual();
                  }}
                  className="w-10 h-10 flex items-center justify-center border border-gold/40 text-gold hover:bg-gold hover:text-void transition-colors"
                  aria-label="Sonraki"
                >
                  <ChevronRight className="w-5 h-5" strokeWidth={1.5} />
                </button>
              </div>
            )}
          </div>

          <div className="lg:col-span-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={active.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.35 }}
              >
                <p className="text-[0.625rem] tracking-[0.22em] uppercase text-gold mb-3">
                  {active.brand}
                  <span className="mx-2 text-line-strong">·</span>
                  {active.category}
                  <span className="mx-2 text-line-strong">·</span>
                  {active.gender}
                </p>
                <h3 className="font-display text-3xl sm:text-4xl md:text-5xl tracking-[0.03em] text-cream leading-tight">
                  {active.name}
                </h3>
                <p className="mt-5 text-[0.9375rem] font-light leading-relaxed text-cream-muted max-w-md">
                  {active.shortDescription}
                </p>
                <div className="mt-6 flex items-baseline gap-3">
                  <span className="text-2xl tracking-wide text-gold tabular-nums font-medium">
                    {formatPrice(active.price100)}
                  </span>
                  <span className="text-[0.6875rem] tracking-[0.14em] uppercase text-muted">100 ml</span>
                </div>
                <div className="mt-8 flex flex-wrap gap-3">
                  <button type="button" onClick={() => onOpenProduct(active)} className="btn-primary">
                    İncele
                  </button>
                  <button type="button" onClick={onViewAll} className="btn-secondary">
                    Tüm Koleksiyon
                  </button>
                </div>
              </motion.div>
            </AnimatePresence>

            {n > 1 && (
              <div className="mt-8 flex gap-2.5 overflow-x-auto scrollbar-none">
                {list.map((p, i) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      goTo(i);
                      bumpManual();
                    }}
                    className={`shrink-0 w-16 h-20 border transition-all duration-300 bg-[#f5f3ee] ${
                      i === index ? 'border-gold opacity-100' : 'border-line opacity-45 hover:opacity-75'
                    }`}
                  >
                    <img src={p.image} alt="" className="w-full h-full object-contain p-1" draggable={false} />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
