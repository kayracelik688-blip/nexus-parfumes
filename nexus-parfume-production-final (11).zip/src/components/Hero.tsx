interface HeroProps {
  onExplore: (family?: string) => void;
}

export default function Hero({ onExplore }: HeroProps) {
  return (
    <section
      id="hero"
      className="relative min-h-[88dvh] md:min-h-[92dvh] flex items-center overflow-hidden bg-void"
    >
      {/* Soft gold ambient — logo uyumu */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_30%,rgba(212,180,90,0.12),transparent_55%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_80%_70%,rgba(212,180,90,0.05),transparent_45%)]" />
      </div>

      <div className="container-page relative z-10 w-full pt-28 pb-16 md:pt-32 md:pb-20">
        {/* Sadece yazı — sağda parfüm yok */}
        <div className="max-w-3xl mx-auto text-center">
          <p className="eyebrow mb-6 md:mb-8 text-gold">Niş Parfüm Koleksiyonu</p>

          <h1 className="font-display text-[2.85rem] sm:text-5xl md:text-6xl xl:text-[4.35rem] leading-[1.05] tracking-[0.02em] text-cream font-normal">
            Kokunun
            <br />
            <span className="italic font-normal text-gold">kesişim</span> noktası
          </h1>

          <div className="mt-6 md:mt-8 mx-auto h-px w-14 bg-gold" />

          <p className="mt-6 md:mt-8 mx-auto max-w-lg text-[0.9375rem] md:text-base font-light leading-[1.75] text-cream-muted">
            Arap esintili seçkiler ve imza notalar. Oud’dan ambere, deriden miske —
            her formül özenle dengelenmiş bir karakter taşır.
          </p>

          <div className="mt-9 md:mt-11 flex flex-col sm:flex-row flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => onExplore()}
              className="btn-primary w-full sm:w-auto min-w-[11rem]"
            >
              Koleksiyonu Keşfet
            </button>
            <button
              type="button"
              onClick={() => onExplore('Oud')}
              className="btn-secondary w-full sm:w-auto min-w-[11rem]"
            >
              Oud Keşfet
            </button>
            <button
              type="button"
              onClick={() => onExplore('Amber')}
              className="btn-secondary w-full sm:w-auto min-w-[11rem]"
            >
              Amber Keşfet
            </button>
          </div>

          <div className="mt-12 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[0.6875rem] tracking-[0.14em] uppercase text-muted">
            <span>100 ml</span>
            <span className="hidden sm:inline text-line-strong">|</span>
            <span>WhatsApp sipariş</span>
            <span className="hidden sm:inline text-line-strong">|</span>
            <span>Gerçek markalar</span>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div className="pointer-events-none absolute bottom-6 left-1/2 -translate-x-1/2 hidden md:flex flex-col items-center gap-2">
        <span className="text-[0.5625rem] tracking-[0.28em] uppercase text-muted">Kaydır</span>
        <span className="block h-8 w-px bg-gradient-to-b from-gold/70 to-transparent" />
      </div>

      <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-px bg-line" />
    </section>
  );
}
