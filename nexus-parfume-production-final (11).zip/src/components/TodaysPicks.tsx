import { motion } from 'framer-motion';
import { products, formatPrice, type Product } from '../data/products';

interface TodaysPicksProps {
  onOpenProduct: (p: Product) => void;
  onViewAll: () => void;
}

export default function TodaysPicks({ onOpenProduct, onViewAll }: TodaysPicksProps) {
  const picks = products.filter((p) => p.featured).slice(0, 3);
  const list = picks.length > 0 ? picks : products.slice(0, 3);
  if (list.length === 0) return null;

  return (
    <section
      id="gunun-seckileri"
      className="relative pt-12 pb-16 md:pt-16 md:pb-20 bg-void border-t border-gold/20"
      aria-labelledby="picks-title"
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_0%,rgba(232,197,71,0.06),transparent_50%)]" />

      <div className="container-page relative z-10">
        <header className="mb-8 md:mb-12 max-w-xl">
          <motion.p
            className="text-[0.6875rem] tracking-[0.28em] uppercase text-gold mb-3"
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-8%' }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          >
            Bugün
          </motion.p>
          <motion.h2
            id="picks-title"
            className="section-title text-3xl sm:text-4xl md:text-[2.6rem]"
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-8%' }}
            transition={{ duration: 0.4, delay: 0.05, ease: [0.22, 1, 0.36, 1] }}
          >
            Günün <span className="text-gold italic">Seçkileri</span>
          </motion.h2>
          <motion.div
            className="mt-4 h-px w-12 bg-gold"
            initial={{ scaleX: 0, opacity: 0 }}
            whileInView={{ scaleX: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: 0.1 }}
            style={{ transformOrigin: 'left' }}
          />
        </header>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-5 md:gap-6">
          {list.map((product, i) => (
            <motion.button
              key={product.id}
              type="button"
              onClick={() => onOpenProduct(product)}
              initial={{ opacity: 0, y: 18, scale: 0.98 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true, margin: '-6%' }}
              transition={{
                duration: 0.4,
                delay: 0.08 + i * 0.1,
                ease: [0.22, 1, 0.36, 1],
              }}
              className="group text-left border border-line hover:border-gold/45 bg-ink-soft transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold/40"
            >
              <div className="relative aspect-[3/4] overflow-hidden bg-[#f5f3ee]">
                <img
                  src={product.image}
                  alt={`${product.brand} ${product.name}`}
                  loading="lazy"
                  className="absolute inset-0 h-full w-full object-contain object-center p-4 transition-transform duration-400 ease-out group-hover:scale-[1.04]"
                />
                <div className="absolute top-3 left-3">
                  <span className="text-[0.5rem] tracking-[0.2em] uppercase text-gold bg-void/70 backdrop-blur-sm px-2 py-0.5 border border-gold/30">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                </div>
              </div>
              <div className="p-4 sm:p-5 border-t border-line group-hover:border-gold/25 transition-colors">
                <p className="text-[0.5625rem] tracking-[0.16em] uppercase text-gold mb-1.5">
                  {product.brand}
                </p>
                <h3 className="font-display text-xl tracking-[0.04em] text-cream group-hover:text-gold transition-colors duration-300">
                  {product.name}
                </h3>
                <div className="mt-3 flex items-baseline justify-between gap-2">
                  <span className="text-sm text-cream tabular-nums">
                    {formatPrice(product.price100)}
                    <span className="text-muted text-[0.625rem] ml-1">/ 100 ml</span>
                  </span>
                  <span className="text-[0.5625rem] tracking-[0.14em] uppercase text-muted group-hover:text-gold transition-colors">
                    İncele →
                  </span>
                </div>
              </div>
            </motion.button>
          ))}
        </div>

        <motion.div
          className="mt-8 flex justify-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.35, delay: 0.25 }}
        >
          <button type="button" onClick={onViewAll} className="btn-secondary">
            Tüm Koleksiyon
          </button>
        </motion.div>
      </div>
    </section>
  );
}
