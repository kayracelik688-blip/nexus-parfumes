import { useCallback, useEffect, useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Featured from './components/Featured';
import OrderSteps from './components/OrderSteps';
import Collection from './components/Collection';
import ScentFamilies from './components/ScentFamilies';
import About from './components/About';
import InstagramBand from './components/InstagramBand';
import Footer from './components/Footer';
import ProductModal from './components/ProductModal';
import CartDrawer from './components/CartDrawer';
import Toast from './components/Toast';
import BackToTop from './components/BackToTop';
import { DEFAULT_FILTERS, type FilterState } from './components/Filters';
import { getProductById, type Product, type ScentFamily } from './data/products';
import { useCart } from './hooks/useCart';
import type { BottleSize } from './hooks/useCart';
import { ThemeProvider } from './context/ThemeContext';

const SECTION_IDS = ['hero', 'aileler', 'koleksiyon', 'hakkimizda', 'iletisim'] as const;

function scrollToId(id: string) {
  if (id === 'hero') {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return;
  }
  const el = document.getElementById(id);
  if (!el) return;
  const headerOffset = 80;
  const y = el.getBoundingClientRect().top + window.scrollY - headerOffset;
  window.scrollTo({ top: Math.max(0, y), behavior: 'smooth' });
}

export default function App() {
  const cart = useCart();
  const [cartOpen, setCartOpen] = useState(false);
  const [selected, setSelected] = useState<Product | null>(null);
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const elements = SECTION_IDS.map((id) => document.getElementById(id)).filter(
      Boolean
    ) as HTMLElement[];

    if (elements.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (visible[0]?.target?.id) {
          setActiveSection(visible[0].target.id);
        }
      },
      {
        rootMargin: '-20% 0px -55% 0px',
        threshold: [0, 0.15, 0.35, 0.55],
      }
    );

    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const applyFamilyFilter = useCallback((family: ScentFamily) => {
    setFilters({
      ...DEFAULT_FILTERS,
      categories: [family],
    });
    requestAnimationFrame(() => {
      scrollToId('koleksiyon');
    });
  }, []);

  const explore = useCallback(
    (family?: string) => {
      if (family === 'Oud' || family === 'Amber') {
        applyFamilyFilter(family);
        return;
      }
      setFilters({ ...DEFAULT_FILTERS });
      scrollToId('koleksiyon');
    },
    [applyFamilyFilter]
  );

  const handleNavigate = useCallback((section: string) => {
    scrollToId(section);
  }, []);

  const handleAddToCart = useCallback(
    (productId: string, size: BottleSize, quantity: number) => {
      cart.addItem(productId, size, quantity);
      const product = getProductById(productId);
      setToast(
        product
          ? `${product.name} · ${size} ml sepete eklendi`
          : 'Ürün sepete eklendi'
      );
      setCartOpen(true);
    },
    [cart]
  );

  return (
    <ThemeProvider>
    <div className="min-h-dvh bg-void text-cream overflow-x-hidden">
      <Header
        cartCount={cart.totalItems}
        onOpenCart={() => setCartOpen(true)}
        onNavigate={handleNavigate}
        activeSection={activeSection}
      />

      <main>
        <Hero onExplore={explore} />
        <Featured
          onOpenProduct={setSelected}
          onViewAll={() => {
            setFilters({ ...DEFAULT_FILTERS });
            scrollToId('koleksiyon');
          }}
        />
        <ScentFamilies onSelect={applyFamilyFilter} />
        <OrderSteps />
        <Collection
          filters={filters}
          onFiltersChange={setFilters}
          onOpenProduct={setSelected}
          mobileFiltersOpen={mobileFiltersOpen}
          onMobileFiltersOpenChange={setMobileFiltersOpen}
        />
        <About />
        <InstagramBand />
      </main>

      <Footer onFamilyClick={applyFamilyFilter} onNavigate={handleNavigate} />

      <ProductModal
        product={selected}
        onClose={() => setSelected(null)}
        onAddToCart={handleAddToCart}
      />

      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} cart={cart} />

      <Toast message={toast} onDismiss={() => setToast(null)} />
      <BackToTop />
    </div>
    </ThemeProvider>
  );
}
