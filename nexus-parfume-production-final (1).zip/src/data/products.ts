export type ScentFamily =
  | 'Amber'
  | 'Oud'
  | 'Odunsu'
  | 'Çiçeksi'
  | 'Fresh'
  | 'Baharatlı'
  | 'Misk'
  | 'Deri';

export type ProductType = 'NEXUS Seçkisi' | 'Arap Esintili';
export type Gender = 'Kadın' | 'Erkek' | 'Unisex';
export type Season = 'İlkbahar' | 'Yaz' | 'Sonbahar' | 'Kış' | 'Dört Mevsim';
export type Occasion = 'Gündüz' | 'Gece' | 'Özel Gün' | 'Günlük' | 'Ofis';
export type Intensity = 'Hafif' | 'Orta' | 'Yoğun' | 'Çok Yoğun';

export interface Product {
  id: string;
  name: string;
  brand: string;
  slug: string;
  type: ProductType;
  category: ScentFamily;
  gender: Gender;
  season: Season[];
  occasion: Occasion[];
  intensity: Intensity;
  price50: number;
  price100: number;
  image: string;
  topNotes: string[];
  heartNotes: string[];
  baseNotes: string[];
  shortDescription: string;
  longDescription: string;
  featured?: boolean;
}

export const SCENT_FAMILIES: ScentFamily[] = [
  'Amber',
  'Oud',
  'Odunsu',
  'Çiçeksi',
  'Fresh',
  'Baharatlı',
  'Misk',
  'Deri',
];

export const PRODUCT_TYPES: ProductType[] = ['NEXUS Seçkisi', 'Arap Esintili'];
export const GENDERS: Gender[] = ['Kadın', 'Erkek', 'Unisex'];
export const SEASONS: Season[] = ['İlkbahar', 'Yaz', 'Sonbahar', 'Kış', 'Dört Mevsim'];
export const OCCASIONS: Occasion[] = ['Gündüz', 'Gece', 'Özel Gün', 'Günlük', 'Ofis'];

export const products: Product[] = [
  {
    id: 'afnan-supremacy-collectors-edition',
    name: "Supremacy Collector's Edition",
    brand: 'Afnan',
    slug: 'afnan-supremacy-collectors-edition',
    type: 'Arap Esintili',
    category: 'Fresh',
    gender: 'Erkek',
    season: ['İlkbahar', 'Yaz', 'Dört Mevsim'],
    occasion: ['Gündüz', 'Günlük', 'Ofis'],
    intensity: 'Yoğun',
    price50: 2490,
    price100: 2490,
    image: '/images/perfume-supremacy.jpg',
    topNotes: ['Limon', 'Bergamot', 'Lavanta'],
    heartNotes: ['Baharat', 'Sedir', 'Gül'],
    baseNotes: ['Ambergris', 'Misk', 'Sandal Ağacı'],
    shortDescription: 'Collector’s Edition — taze, kalıcı ve ikonik Afnan imzası.',
    longDescription:
      'Afnan Supremacy Collector’s Edition, limon ve bergamotun ferah açılışını lavanta ve baharat notalarıyla derinleştirir. Ambergris ve sandal ağacıyla uzun süre kalıcı, modern ve asil bir erkek profili sunar.',
    featured: true,
  },
  {
    id: 'lattafa-khamrah-qahwa',
    name: 'Khamrah Qahwa',
    brand: 'Lattafa',
    slug: 'lattafa-khamrah-qahwa',
    type: 'Arap Esintili',
    category: 'Amber',
    gender: 'Unisex',
    season: ['Sonbahar', 'Kış'],
    occasion: ['Gece', 'Özel Gün', 'Günlük'],
    intensity: 'Yoğun',
    price50: 2600,
    price100: 2600,
    image: '/images/perfume-gold.jpg',
    topNotes: ['Zencefil', 'Tarçın', 'Kakule'],
    heartNotes: ['Pralin', 'Şekerlenmiş Meyveler', 'Beyaz Çiçekler'],
    baseNotes: ['Kahve Arabica', 'Tonka Fasulyesi', 'Misk', 'Benzoin', 'Vanilya'],
    shortDescription: 'Baharat, pralin ve kahvenin sıcak gourmand yorumu.',
    longDescription:
      'Lattafa Khamrah Qahwa, Khamrah karakterini kahve dokunuşuyla zenginleştirir. Zencefil ve tarçın açılışı, pralin ve vanilya ile birleşerek sıcak, tatlı ve yoğun bir gece kokusu oluşturur.',
    featured: true,
  },
  {
    id: 'rasasi-hawas-ice',
    name: 'Hawas Ice',
    brand: 'Rasasi',
    slug: 'rasasi-hawas-ice',
    type: 'Arap Esintili',
    category: 'Fresh',
    gender: 'Erkek',
    season: ['İlkbahar', 'Yaz'],
    occasion: ['Gündüz', 'Günlük', 'Ofis'],
    intensity: 'Orta',
    price50: 2190,
    price100: 2190,
    image: '/images/perfume-hawas-malibu.jpg',
    topNotes: ['Limon', 'Elma', 'Bergamot'],
    heartNotes: ['Lavanta', 'Portakal Çiçeği', 'Su Notaları'],
    baseNotes: ['Ambergris', 'Misk', 'Sedir'],
    shortDescription: 'Buz gibi ferah, modern ve kalıcı Hawas yorumu.',
    longDescription:
      'Rasasi Hawas Ice, klasik Hawas enerjisini daha serin ve taze bir profile taşır. Gündüz ve sıcak havalarda ferahlık arayanlar için idealdir.',
    featured: true,
  },
  {
    id: 'rasasi-hawas-tropical',
    name: 'Hawas Tropical',
    brand: 'Rasasi',
    slug: 'rasasi-hawas-tropical',
    type: 'Arap Esintili',
    category: 'Fresh',
    gender: 'Erkek',
    season: ['İlkbahar', 'Yaz'],
    occasion: ['Gündüz', 'Günlük'],
    intensity: 'Orta',
    price50: 2290,
    price100: 2290,
    image: '/images/perfume-hawas-tropical.jpg',
    topNotes: ['İncir Yaprağı', 'Hindistan Cevizi Suyu', 'Zencefil'],
    heartNotes: ['Tropik Meyveler', 'Yasemin'],
    baseNotes: ['Amber', 'Misk', 'Sandal'],
    shortDescription: 'Tropik ferahlık ve canlı Hawas karakteri.',
    longDescription:
      'Hawas Tropical, incir yaprağı, hindistan cevizi suyu ve zencefilin ferah açılışını tropik notalarla birleştirir. Sıcak havalarda gündüz kullanımı için tasarlanmış modern bir fresh profildir.',
  },
  {
    id: 'rasasi-hawas-viper',
    name: 'Hawas Viper',
    brand: 'Rasasi',
    slug: 'rasasi-hawas-viper',
    type: 'Arap Esintili',
    category: 'Baharatlı',
    gender: 'Erkek',
    season: ['Sonbahar', 'Kış', 'Dört Mevsim'],
    occasion: ['Gece', 'Günlük'],
    intensity: 'Yoğun',
    price50: 2390,
    price100: 2390,
    image: '/images/perfume-hawas-viper.jpg',
    topNotes: ['Karabiber', 'Greyfurt', 'Lavanta'],
    heartNotes: ['Baharat', 'Sedir'],
    baseNotes: ['Ambergris', 'Misk', 'Odunsu Notalar'],
    shortDescription: 'Keskin, baharatlı ve güçlü Hawas varyasyonu.',
    longDescription:
      'Hawas Viper, daha keskin ve baharatlı bir karakter sunar. Gece ve serin havalarda dikkat çeken, kalıcı bir erkek kokusu.',
  },
  {
    id: 'rasasi-hawas-london',
    name: 'Hawas London',
    brand: 'Rasasi',
    slug: 'rasasi-hawas-london',
    type: 'Arap Esintili',
    category: 'Fresh',
    gender: 'Erkek',
    season: ['İlkbahar', 'Yaz', 'Sonbahar'],
    occasion: ['Ofis', 'Gündüz', 'Günlük'],
    intensity: 'Orta',
    price50: 2250,
    price100: 2250,
    image: '/images/perfume-hawas-london.jpg',
    topNotes: ['Narenciye', 'Yeşil Notalar'],
    heartNotes: ['Lavanta', 'Baharat'],
    baseNotes: ['Amber', 'Misk', 'Sedir'],
    shortDescription: 'Zarif, modern ve ofise uygun Hawas yorumu.',
    longDescription:
      'Hawas London, daha rafine ve dengeli bir Hawas karakteri sunar. Ofis ve gündelik kullanım için ferah ama kalıcı bir seçimdir.',
  },
  {
    id: 'lattafa-asad',
    name: 'Asad',
    brand: 'Lattafa',
    slug: 'lattafa-asad',
    type: 'Arap Esintili',
    category: 'Baharatlı',
    gender: 'Erkek',
    season: ['Sonbahar', 'Kış'],
    occasion: ['Gece', 'Özel Gün'],
    intensity: 'Çok Yoğun',
    price50: 1890,
    price100: 1890,
    image: '/images/perfume-asad.jpg',
    topNotes: ['Karabiber', 'Tütün', 'Ananas'],
    heartNotes: ['Paçuli', 'Kahve', 'Iris'],
    baseNotes: ['Vanilya', 'Amber', 'Kuru Odunlar'],
    shortDescription: 'Karanlık, baharatlı ve ikonik Lattafa imzası.',
    longDescription:
      'Lattafa Asad, karabiber ve tütünle açılan, paçuli ve kahveyle derinleşen, vanilya ve amberle tamamlanan güçlü bir erkek kokusu. Gece ve özel anlar için idealdir.',
    featured: true,
  },
  {
    id: 'maison-alhambra-arabian-tonka',
    name: 'Arabian Tonka',
    brand: 'Maison Alhambra',
    slug: 'maison-alhambra-arabian-tonka',
    type: 'Arap Esintili',
    category: 'Amber',
    gender: 'Unisex',
    season: ['Sonbahar', 'Kış'],
    occasion: ['Gece', 'Özel Gün'],
    intensity: 'Çok Yoğun',
    price50: 3000,
    price100: 3000,
    image: '/images/perfume-dark-gold.jpg',
    topNotes: ['Safran', 'Bergamot'],
    heartNotes: ['Oud', 'Gül'],
    baseNotes: ['Amber', 'Meşe Yosunu', 'Tonka Fasulyesi', 'Deri', 'Beyaz Misk'],
    shortDescription: 'Safran, oud, gül ve tonkanın güçlü amber yorumu.',
    longDescription:
      'Arabian Tonka; safran ve bergamotla açılan, gül ve oud ile yoğunlaşan, tonka, amber, deri ve beyaz miskle derinleşen sıcak ve güçlü bir koku profili sunar.',
  },
  {
    id: 'french-avenue-liquid-brun',
    name: 'Liquid Brun',
    brand: 'French Avenue',
    slug: 'french-avenue-liquid-brun',
    type: 'Arap Esintili',
    category: 'Amber',
    gender: 'Erkek',
    season: ['Sonbahar', 'Kış'],
    occasion: ['Gece', 'Özel Gün', 'Günlük'],
    intensity: 'Yoğun',
    price50: 2899,
    price100: 2899,
    image: '/images/perfume-vulcan-feu.jpg',
    topNotes: ['Tarçın', 'Bergamot', 'Kakule', 'Portakal Çiçeği'],
    heartNotes: ['Bourbon Vanilyası', 'Elemi'],
    baseNotes: ['Misk', 'Pralin', 'Ambroksan', 'Guaiac Ağacı'],
    shortDescription: 'Tarçın, bourbon vanilyası ve pralinle sıcak amber-vanilya.',
    longDescription:
      'French Avenue Liquid Brun, tarçın ve bergamotla açılan; bourbon vanilyası ve elemiyle kremsi bir kalbe geçen; pralin, ambroksan ve guaiac ağacıyla tamamlanan sıcak ve gourmand bir kompozisyondur.',
  },
  {
    id: 'lattafa-najdia',
    name: 'Najdia',
    brand: 'Lattafa',
    slug: 'lattafa-najdia',
    type: 'Arap Esintili',
    category: 'Fresh',
    gender: 'Unisex',
    season: ['İlkbahar', 'Yaz'],
    occasion: ['Gündüz', 'Günlük'],
    intensity: 'Orta',
    price50: 1650,
    price100: 1650,
    image: '/images/perfume-safari-breeze.jpg',
    topNotes: ['Limon', 'Elma', 'Ananas'],
    heartNotes: ['Lavanta', 'Yasemin'],
    baseNotes: ['Ambergris', 'Misk', 'Sedir'],
    shortDescription: 'Ferah, meyvemsi ve modern günlük koku.',
    longDescription:
      'Lattafa Najdia, narenciye ve meyve notalarıyla açılan, lavanta ve yaseminle dengelenen, ambergris ve miskle kalıcı hale gelen ferah bir uniseks parfümdür.',
  },
];

export function getProductById(id: string): Product | undefined {
  return products.find((p) => p.id === id);
}

export function formatPrice(n: number): string {
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(n);
}
