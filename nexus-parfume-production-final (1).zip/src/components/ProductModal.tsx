import { useEffect, useMemo, useState } from 'react';
import { Minus, Plus, ShoppingBag, X, MessageCircle } from 'lucide-react';
import type { Product } from '../data/products';
import { formatPrice } from '../data/products';
import type { BottleSize } from '../hooks/useCart';
import { buildProductWhatsAppUrl } from '../lib/whatsapp';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (productId: string, size: BottleSize, quantity: number) => void;
}

export default function ProductModal({ product, onClose, onAddToCart }: ProductModalProps) {
  const [size, setSize] = useState<BottleSize>(50);
  const [qty, setQty] = useState(1);

  useEffect(() => {
    if (product) {
      setSize(50);
      setQty(1);
    }
  }, [product?.id]);

  useEffect(() => {
    if (!product) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
  }, [product, onClose]);

  const unitPrice = useMemo(() => {
    if (!product) return 0;
    return size === 50 ? product.price50 : product.price100;
  }, [product, size]);

  const lineTotal = unitPrice * qty;

  const whatsappUrl = useMemo(() => {
    if (!product) return '#';
    return buildProductWhatsAppUrl(product.name, size, unitPrice, qty);
  }, [product, size, unitPrice, qty]);

  if (!product) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-5"
      role="dialog"
      aria-modal="true"
      aria-labelledby="product-modal-title"
    >
      <button
        type="button"
        className="absolute inset-0 bg-black/80"
        aria-label="Kapat"
        onClick={onClose}
      />

      <div className="relative w-full sm:max-w-3xl max-h-[92dvh] sm:max-h-[90vh] overflow-hidden border border-line bg-ink-soft shadow-2xl flex flex-col sm:rounded-none">
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-3.5 border-b border-line shrink-0">
          <span className="text-[0.625rem] tracking-[0.24em] uppercase text-muted">
            Ürün Detayı
          </span>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-cream-muted hover:text-cream transition-colors"
            aria-label="Kapat"
          >
            <X className="w-5 h-5" strokeWidth={1.5} />
          </button>
        </div>

        <div className="overflow-y-auto overscroll-contain flex-1">
          <div className="grid sm:grid-cols-2 gap-0">
            <div className="relative aspect-[4/5] sm:aspect-auto sm:min-h-[420px] img-frame">
              <img
                src={product.image}
                alt={product.name}
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-soft/70 via-transparent to-transparent sm:hidden" />
            </div>

            <div className="p-5 sm:p-7 flex flex-col gap-5 safe-pb">
              <div>
                <div className="flex flex-wrap gap-2 mb-3">
                  <span className="text-[0.5625rem] tracking-[0.16em] uppercase text-cream-muted border border-line px-2.5 py-1">
                    {product.brand}
                  </span>
                  <span className="text-[0.5625rem] tracking-[0.16em] uppercase text-cream-muted border border-line px-2.5 py-1">
                    {product.category}
                  </span>
                  <span className="text-[0.5625rem] tracking-[0.16em] uppercase text-muted border border-line px-2.5 py-1">
                    {product.type}
                  </span>
                  <span className="text-[0.5625rem] tracking-[0.16em] uppercase text-muted border border-line px-2.5 py-1">
                    {product.gender}
                  </span>
                </div>
                <h2
                  id="product-modal-title"
                  className="font-display text-3xl sm:text-[2.15rem] tracking-[0.06em] text-cream leading-tight"
                >
                  {product.name}
                </h2>
                <p className="mt-3 text-[0.875rem] font-light leading-[1.75] text-cream-muted">
                  {product.longDescription}
                </p>
              </div>

              {/* Notes */}
              <div className="grid grid-cols-3 gap-px bg-line border border-line">
                {[
                  { label: 'Üst', notes: product.topNotes },
                  { label: 'Kalp', notes: product.heartNotes },
                  { label: 'Dip', notes: product.baseNotes },
                ].map((n) => (
                  <div key={n.label} className="bg-ink-card px-2.5 py-3 text-center">
                    <p className="text-[0.5625rem] tracking-[0.18em] uppercase text-muted mb-1.5">
                      {n.label}
                    </p>
                    <p className="text-[0.6875rem] font-light leading-snug text-cream-muted">
                      {n.notes.join(', ')}
                    </p>
                  </div>
                ))}
              </div>

              <div className="flex flex-wrap gap-x-5 gap-y-1.5 text-[0.75rem] font-light text-cream-muted">
                <span>
                  Mevsim: <span className="text-cream-soft">{product.season.join(', ')}</span>
                </span>
                <span>
                  Kullanım: <span className="text-cream-soft">{product.occasion.join(', ')}</span>
                </span>
                <span>
                  Yoğunluk: <span className="text-cream-soft">{product.intensity}</span>
                </span>
              </div>

              {/* Size */}
              <div>
                <p className="text-[0.625rem] tracking-[0.2em] uppercase text-muted mb-2.5">
                  Boyut
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {([50, 100] as BottleSize[]).map((s) => {
                    const price = s === 50 ? product.price50 : product.price100;
                    const active = size === s;
                    return (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setSize(s)}
                        className={`border px-3 py-3 text-left transition-colors duration-200 ${
                          active
                            ? 'border-cream/50 bg-cream/[0.04] text-cream'
                            : 'border-line bg-ink-card text-cream-muted hover:border-line-strong'
                        }`}
                      >
                        <span className="block text-sm font-normal tracking-wide">{s} ml</span>
                        <span
                          className={`block text-xs mt-1 font-light ${
                            active ? 'text-gold' : 'text-muted'
                          }`}
                        >
                          {formatPrice(price)}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Qty */}
              <div className="flex items-center justify-between gap-3">
                <p className="text-[0.625rem] tracking-[0.2em] uppercase text-muted">Adet</p>
                <div className="flex items-center gap-3 border border-line bg-ink-card px-2 py-1">
                  <button
                    type="button"
                    onClick={() => setQty((q) => Math.max(1, q - 1))}
                    className="p-1.5 text-cream-muted hover:text-cream transition-colors"
                    aria-label="Azalt"
                  >
                    <Minus className="w-4 h-4" strokeWidth={1.5} />
                  </button>
                  <span className="w-6 text-center text-sm font-normal">{qty}</span>
                  <button
                    type="button"
                    onClick={() => setQty((q) => Math.min(20, q + 1))}
                    className="p-1.5 text-cream-muted hover:text-cream transition-colors"
                    aria-label="Artır"
                  >
                    <Plus className="w-4 h-4" strokeWidth={1.5} />
                  </button>
                </div>
              </div>

              <div className="border border-line bg-ink-card px-4 py-3.5 flex items-center justify-between">
                <span className="text-[0.75rem] tracking-[0.12em] uppercase text-muted">
                  Toplam
                </span>
                <span className="text-lg font-normal tracking-wide text-cream">
                  {formatPrice(lineTotal)}
                </span>
              </div>

              <div className="flex flex-col gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    onAddToCart(product.id, size, qty);
                    onClose();
                  }}
                  className="btn-primary w-full"
                >
                  <ShoppingBag className="w-4 h-4" strokeWidth={1.5} />
                  Sepete Ekle
                </button>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary w-full"
                >
                  <MessageCircle className="w-4 h-4" strokeWidth={1.5} />
                  WhatsApp ile Sipariş
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
