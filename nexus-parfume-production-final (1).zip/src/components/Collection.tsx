import { useMemo } from 'react';
import { X } from 'lucide-react';
import { products, type Product } from '../data/products';
import ProductCard from './ProductCard';
import Filters, { DEFAULT_FILTERS, type FilterState } from './Filters';
import { filterAndSortProducts } from '../lib/filterProducts';

interface CollectionProps {
  filters: FilterState;
  onFiltersChange: (f: FilterState) => void;
  onOpenProduct: (p: Product) => void;
  mobileFiltersOpen: boolean;
  onMobileFiltersOpenChange: (open: boolean) => void;
}

export default function Collection({
  filters,
  onFiltersChange,
  onOpenProduct,
  mobileFiltersOpen,
  onMobileFiltersOpenChange,
}: CollectionProps) {
  const filtered = useMemo(() => filterAndSortProducts(products, filters), [filters]);

  const activeChips = useMemo(() => {
    const chips: { key: string; label: string; clear: () => void }[] = [];

    filters.categories.forEach((c) => {
      chips.push({
        key: `cat-${c}`,
        label: c,
        clear: () =>
          onFiltersChange({
            ...filters,
            categories: filters.categories.filter((x) => x !== c),
          }),
      });
    });
    filters.types.forEach((t) => {
      chips.push({
        key: `type-${t}`,
        label: t,
        clear: () =>
          onFiltersChange({
            ...filters,
            types: filters.types.filter((x) => x !== t),
          }),
      });
    });
    filters.genders.forEach((g) => {
      chips.push({
        key: `gen-${g}`,
        label: g,
        clear: () =>
          onFiltersChange({
            ...filters,
            genders: filters.genders.filter((x) => x !== g),
          }),
      });
    });
    filters.seasons.forEach((s) => {
      chips.push({
        key: `sea-${s}`,
        label: s,
        clear: () =>
          onFiltersChange({
            ...filters,
            seasons: filters.seasons.filter((x) => x !== s),
          }),
      });
    });
    filters.occasions.forEach((o) => {
      chips.push({
        key: `occ-${o}`,
        label: o,
        clear: () =>
          onFiltersChange({
            ...filters,
            occasions: filters.occasions.filter((x) => x !== o),
          }),
      });
    });
    if (filters.search.trim()) {
      chips.push({
        key: 'search',
        label: `“${filters.search.trim()}”`,
        clear: () => onFiltersChange({ ...filters, search: '' }),
      });
    }

    return chips;
  }, [filters, onFiltersChange]);

  return (
    <section id="koleksiyon" className="relative section-pad bg-ink border-t border-line">
      <div className="container-page">
        <header className="mb-10 md:mb-14 max-w-xl">
          <p className="eyebrow mb-4">Koleksiyon</p>
          <h2 className="section-title text-3xl sm:text-4xl md:text-[2.75rem]">Tüm parfümler</h2>
          <p className="section-lead mt-4">
            Koku ailesi, cinsiyet, mevsim, kullanım, tür ve fiyata göre filtreleyin. Filtreler
            birlikte çalışır.
          </p>
        </header>

        <div className="lg:grid lg:grid-cols-[240px_minmax(0,1fr)] xl:grid-cols-[260px_minmax(0,1fr)] lg:gap-10 xl:gap-14">
          <Filters
            filters={filters}
            onChange={onFiltersChange}
            resultCount={filtered.length}
            mobileOpen={mobileFiltersOpen}
            onMobileOpenChange={onMobileFiltersOpenChange}
          />

          <div className="min-w-0">
            <div className="mb-6 sm:mb-8 pb-4 border-b border-line space-y-3">
              <div className="flex items-center justify-between gap-3">
                <p className="text-[0.75rem] tracking-[0.12em] uppercase text-cream-muted">
                  <span className="text-cream">{filtered.length}</span> ürün
                </p>
                {activeChips.length > 0 && (
                  <button
                    type="button"
                    onClick={() => onFiltersChange({ ...DEFAULT_FILTERS })}
                    className="text-[0.6875rem] tracking-[0.12em] uppercase text-muted hover:text-cream transition-colors"
                  >
                    Tümünü temizle
                  </button>
                )}
              </div>

              {activeChips.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {activeChips.map((chip) => (
                    <button
                      key={chip.key}
                      type="button"
                      onClick={chip.clear}
                      className="inline-flex items-center gap-1.5 border border-line bg-ink-card px-2.5 py-1.5 text-[0.6875rem] tracking-wide text-cream-soft hover:border-line-strong transition-colors"
                    >
                      {chip.label}
                      <X className="w-3 h-3 text-muted" strokeWidth={1.5} />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {filtered.length === 0 ? (
              <div className="border border-line bg-ink-card px-6 py-20 text-center">
                <p className="font-display text-2xl tracking-wide text-cream mb-3">
                  Sonuç bulunamadı
                </p>
                <p className="section-lead mb-8 max-w-sm mx-auto">
                  Filtreleri gevşetin veya aramayı temizleyin.
                </p>
                <button
                  type="button"
                  onClick={() => onFiltersChange({ ...DEFAULT_FILTERS })}
                  className="btn-secondary"
                >
                  Filtreleri sıfırla
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-x-5 gap-y-10 sm:gap-x-6 sm:gap-y-12">
                {filtered.map((p) => (
                  <ProductCard key={p.id} product={p} onOpen={onOpenProduct} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
