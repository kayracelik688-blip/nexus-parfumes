import type { Product } from '../data/products';
import { formatPrice } from '../data/products';

interface ProductCardProps {
  product: Product;
  onOpen: (product: Product) => void;
}

export default function ProductCard({ product, onOpen }: ProductCardProps) {
  return (
    <article className="group flex flex-col h-full">
      <button
        type="button"
        onClick={() => onOpen(product)}
        className="text-left flex flex-col h-full focus:outline-none focus-visible:ring-2 focus-visible:ring-gold/50 rounded-sm"
      >
        {/* Image */}
        <div className="relative aspect-[3/4] overflow-hidden img-frame border border-line group-hover:border-line-strong transition-colors duration-300 bg-ink-soft">
          <img
            src={product.image}
            alt={`${product.brand} ${product.name}`}
            loading="lazy"
            decoding="async"
            className="absolute inset-0 h-full w-full object-cover object-center transition-transform duration-500 ease-out group-hover:scale-[1.04]"
            onError={(e) => {
              e.currentTarget.src = '/images/hero-bottle.jpg';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-void/60 via-transparent to-transparent pointer-events-none" />

          <div className="absolute top-3 left-3">
            <span className="inline-block bg-void/60 backdrop-blur-[2px] border border-line px-2.5 py-1 text-[0.5625rem] tracking-[0.18em] uppercase text-cream-soft">
              {product.category}
            </span>
          </div>

          <div className="absolute inset-x-0 bottom-0 p-3 sm:p-4 opacity-100 sm:opacity-0 sm:translate-y-1 sm:group-hover:translate-y-0 sm:group-hover:opacity-100 transition-all duration-300">
            <span className="flex items-center justify-center w-full min-h-[40px] border border-cream/25 bg-void/70 backdrop-blur-[2px] text-[0.625rem] tracking-[0.2em] uppercase text-cream">
              İncele
            </span>
          </div>
        </div>

        {/* Meta */}
        <div className="flex flex-col flex-1 pt-4 pb-1 px-0.5">
          <p className="text-[0.625rem] tracking-[0.16em] uppercase text-muted mb-1.5">
            {product.brand}
            <span className="mx-1.5 text-line-strong">·</span>
            {product.gender}
          </p>

          <h3 className="font-display text-[1.2rem] sm:text-[1.3rem] tracking-[0.04em] text-cream leading-snug group-hover:text-cream-soft transition-colors duration-300">
            {product.name}
          </h3>

          <p className="mt-2 text-[0.8125rem] font-light leading-relaxed text-cream-muted line-clamp-2">
            {product.shortDescription}
          </p>

          <div className="mt-auto pt-4 flex items-baseline justify-between gap-3 border-t border-line-soft mt-4">
            <div>
              <p className="text-[0.5625rem] tracking-[0.16em] uppercase text-muted mb-0.5">
                100 ml
              </p>
              <p className="text-[1rem] font-medium tracking-wide text-cream">
                {formatPrice(product.price100)}
              </p>
            </div>
            <span className="text-[0.625rem] tracking-[0.14em] uppercase text-cream-muted group-hover:text-gold transition-colors duration-300">
              Detay →
            </span>
          </div>
        </div>
      </button>
    </article>
  );
}
