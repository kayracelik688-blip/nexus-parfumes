import { useCallback, useEffect, useMemo, useState } from 'react';
import { getProductById } from '../data/products';

export type BottleSize = 50 | 100;

export interface CartItem {
  productId: string;
  size: BottleSize;
  quantity: number;
}

const STORAGE_KEY = 'nexus-cart-v1';

function loadCart(): CartItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as CartItem[];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (i) =>
        i &&
        typeof i.productId === 'string' &&
        (i.size === 50 || i.size === 100) &&
        typeof i.quantity === 'number' &&
        i.quantity > 0 &&
        getProductById(i.productId)
    );
  } catch {
    return [];
  }
}

function saveCart(items: CartItem[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch {
    /* ignore */
  }
}

export function useCart() {
  const [items, setItems] = useState<CartItem[]>(() => loadCart());

  useEffect(() => {
    saveCart(items);
  }, [items]);

  const addItem = useCallback((productId: string, size: BottleSize, quantity = 1) => {
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.productId === productId && i.size === size);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], quantity: next[idx].quantity + quantity };
        return next;
      }
      return [...prev, { productId, size, quantity }];
    });
  }, []);

  const removeItem = useCallback((productId: string, size: BottleSize) => {
    setItems((prev) => prev.filter((i) => !(i.productId === productId && i.size === size)));
  }, []);

  const updateQuantity = useCallback((productId: string, size: BottleSize, quantity: number) => {
    setItems((prev) => {
      if (quantity <= 0) {
        return prev.filter((i) => !(i.productId === productId && i.size === size));
      }
      return prev.map((i) =>
        i.productId === productId && i.size === size ? { ...i, quantity } : i
      );
    });
  }, []);

  const clearCart = useCallback(() => setItems([]), []);

  const totalItems = useMemo(
    () => items.reduce((sum, i) => sum + i.quantity, 0),
    [items]
  );

  const totalPrice = useMemo(() => {
    return items.reduce((sum, i) => {
      const p = getProductById(i.productId);
      if (!p) return sum;
      const unit = i.size === 50 ? p.price50 : p.price100;
      return sum + unit * i.quantity;
    }, 0);
  }, [items]);

  return {
    items,
    addItem,
    removeItem,
    updateQuantity,
    clearCart,
    totalItems,
    totalPrice,
  };
}

export type CartApi = ReturnType<typeof useCart>;
