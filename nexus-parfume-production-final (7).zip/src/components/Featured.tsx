import { useCallback, useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence, useMotionValue } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { products, formatPrice, type Product } from '../data/products';

interface FeaturedProps {
  onOpenProduct: (p: Product) => void;
  onViewAll: () => void;
}

const AUTO_MS = 4800;

export default function Featured({ onOpenProduct, onViewAll }: FeaturedProps) {
  const featured = products.filter((p) => p.featured);
  const list = featured.length > 0 ? featured : products.slice(0, 4);
  const n = list.length;

  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const dragX = useMotionValue(0);
  const resumeTimer = useRef<number | null>(null);
  const autoToken = useRef(0);

  const go = useCallback(
    (dir: number) => {
      setIndex((i) => (i + dir + n) % n);
    },
    [n]
  );

  const goTo = useCallback((i: number) => {
    setIndex(((i % n) + n) % n);
  }, [n]);

  /** Manuel etkileşimden sonra otomatik geçişi kısa süre dondur, sonra devam ettir */
  const bumpManual = useCallback(() => {
    setPaused(true);
    autoToken.current += 1;
    if (resumeTimer.current) window.clearTimeout(resumeTimer.current);
    resumeTimer.current = window.setTimeout(() => {
      setPaused(false);
    }, AUTO_MS);
  }, []);

  // Otomatik geçiş
  useEffect(() => {
    if (paused || n <= 1) return;
    const token = autoToken.current;
    const t = window.setInterval(() => {
      if (autoToken.current !== token) return;
      setIndex((i) => (i + 1) % n);
    }, AUTO_MS);
    return () => clearInterval(t);
  }, [paused, n, index]);

  useEffect(() => {
    return () => {
      if (resumeTimer.current) window.clearTimeout(resumeTimer.current);
    };
  }, []);

  if (n === 0) return null;

  const active = list[index];

  return (
    <section
      className="relative section-pad bg-void border-t border-line overflow-hidden"
      aria-labelledby="featured-title"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => {
        setPaused(false);
      }}
      onTouchStart={() => setPaused(true)}
      onTouchEnd={() => {
        bumpManual();
      }}
    >
      <div className="container-page">
        <header className="mb-10 md:mb-12 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6">
          <div className="max-w-xl">
            <p className="eyebrow mb-4">Öne Çıkanlar</p>
            <h2 id="featured-title" className="section-title text-3xl sm:text-4xl md:text-[2.75rem]">
              İmza seçkisi
            </h2>
            <p className="section-lead mt-4">
              Koleksiyonun en çok tercih edilen parçaları — dengeli, kalıcı ve karakterli.
            </p>
          </div>
          <button type="button" onClick={onViewAll} className="btn-secondary self-start sm:self-auto">
            Tümünü Gör
          </button>
        </header>

        <div className="relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10 items-center">
            <div className="lg:col-span-7 relative">
              <div className="relative aspect-[4/5] sm:aspect-[5/6] lg:aspect-[4/5] overflow-hidden border border-line bg-[#f5f3ee] select-none">
                <AnimatePresence mode="wait">
                  <motion.img
                    key={active.id}
                    src={active.image}
                    alt={`${active.brand} ${active.name}`}
                    initial={{ opacity: 0, x: 28 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -28 }}
                    transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                    className="absolute inset-0 h-full w-full object-contain object-center p-6 sm:p-10 cursor-grab active:cursor-grabbing touch-pan-y"
                    drag="x"
                    dragConstraints={{ left: 0, right: 0 }}
                    dragElastic={0.14}
                    style={{ x: dragX }}
                    onDragStart={() => {
                      setPaused(true);
                    }}
                    onDragEnd={(_, info) => {
                      if (info.offset.x < -50 || info.velocity.x < -200) {
                        go(1);
                        bumpManual();
                      } else if (info.offset.x > 50 || info.velocity.x > 200) {
                        go(-1);
                        bumpManual();
                      } else {
                        bumpManual();
                      }
                    }}
                    onClick={() => onOpenProduct(active)}
                    draggable={false}
                  />
                </AnimatePresence>

                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void/45 via-transparent to-transparent" />

                <div className="absolute top-4 left-4 sm:top-5 sm:left-5">
                  <span className="text-[0.5625rem] tracking-[0.28em] uppercase text-cream-muted bg-void/40 backdrop-blur-sm px-2.5 py-1 border border-line">
                    {String(index + 1).padStart(2, '0')} / {String(n).padStart(2, '0')}
                  </span>
                </div>
              </div>

              {n > 1 && (
                <div className="absolute -bottom-5 right-4 sm:right-6 flex gap-2 z-10">
                  <button
                    type="button"
                    onClick={() => {
                      go(-1);
                      bumpManual();
                    }}
                    className="w-11 h-11 flex items-center justify-center border border-line bg-ink-soft text-cream-muted hover:text-cream hover:border-line-strong transition-colors"
                    aria-label="Önceki"
                  >
                    <ChevronLeft className="w-5 h-5" strokeWidth={1.5} />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      go(1);
                      bumpManual();
                    }}
                    className="w-11 h-11 flex items-center justify-center border border-line bg-ink-soft text-cream-muted hover:text-cream hover:border-line-strong transition-colors"
                    aria-label="Sonraki"
                  >
                    <ChevronRight className="w-5 h-5" strokeWidth={1.5} />
                  </button>
                </div>
              )}
            </div>

            <div className="lg:col-span-5 flex flex-col gap-8 pt-2 lg:pt-0">
              <AnimatePresence mode="wait">
                <motion.div
                  key={active.id + '-info'}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                >
                  <p className="text-[0.625rem] tracking-[0.2em] uppercase text-muted mb-3">
                    {active.brand}
                    <span className="mx-2 text-line-strong">·</span>
                    {active.category}
                    <span className="mx-2 text-line-strong">·</span>
                    {active.gender}
                  </p>
                  <h3 className="font-display text-3xl sm:text-4xl tracking-[0.04em] text-cream leading-tight">
                    {active.name}
                  </h3>
                  <p className="mt-4 text-[0.9375rem] font-light leading-relaxed text-cream-muted max-w-md">
                    {active.shortDescription}
                  </p>
                  <div className="mt-6 flex items-baseline gap-3">
                    <span className="text-xl tracking-wide text-cream tabular-nums">
                      {formatPrice(active.price100)}
                    </span>
                    <span className="text-[0.6875rem] tracking-[0.14em] uppercase text-muted">
                      100 ml
                    </span>
                  </div>
                  <div className="mt-8 flex flex-wrap gap-3">
                    <button
                      type="button"
                      onClick={() => onOpenProduct(active)}
                      className="btn-primary"
                    >
                      İncele
                    </button>
                    <button type="button" onClick={onViewAll} className="btn-secondary">
                      Koleksiyon
                    </button>
                  </div>
                </motion.div>
              </AnimatePresence>

              {n > 1 && (
                <div className="flex gap-3 overflow-x-auto scrollbar-none pb-1 -mx-1 px-1">
                  {list.map((p, i) => {
                    const isActive = i === index;
                    return (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          goTo(i);
                          bumpManual();
                        }}
                        className={`relative shrink-0 w-16 h-20 sm:w-20 sm:h-24 overflow-hidden border transition-all duration-300 bg-[#f5f3ee] ${
                          isActive
                            ? 'border-gold opacity-100 scale-100'
                            : 'border-line opacity-55 hover:opacity-85 scale-[0.97]'
                        }`}
                        aria-label={p.name}
                        aria-current={isActive}
                      >
                        <img
                          src={p.image}
                          alt=""
                          className="w-full h-full object-contain object-center p-1.5"
                          draggable={false}
                        />
                      </button>
                    );
                  })}
                </div>
              )}

              {n > 1 && (
                <div className="flex gap-2" role="tablist" aria-label="Öne çıkanlar">
                  {list.map((p, i) => (
                    <button
                      key={p.id}
                      type="button"
                      role="tab"
                      aria-selected={i === index}
                      onClick={() => {
                        goTo(i);
                        bumpManual();
                      }}
                      className={`h-0.5 transition-all duration-400 ${
                        i === index ? 'w-8 bg-gold' : 'w-4 bg-line-strong hover:bg-cream-muted'
                      }`}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
