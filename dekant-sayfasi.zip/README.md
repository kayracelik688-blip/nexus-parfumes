# Nexus Parfume — Dekant

Bu ZIP bağımsız bir dekant sayfasıdır.

- `index.html` dosyasına çift tıklayarak direkt açabilirsiniz.
- 2 ML / 4 ML seçimi vardır.
- Ürün detay modalı vardır.
- Mobil responsive tasarım içerir.
- Harici paket veya kurulum gerektirmez.
