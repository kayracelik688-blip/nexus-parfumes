import { useCallback, useEffect, useMemo, useState } from 'react';
import { getProductById } from '../data/products';

/** Only 100 ml is sold for now */
export type BottleSize = 100;

export interface CartItem {
  productId: string;
  size: BottleSize;
  quantity: number;
}

const STORAGE_KEY = 'nexus-cart-v2';

function loadCart(): CartItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as CartItem[];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (i) =>
        i &&
        typeof i.productId === 'string' &&
        i.size === 100 &&
        typeof i.quantity === 'number' &&
        i.quantity > 0 &&
        getProductById(i.productId)
    );
  } catch {
    return [];
  }
}

function saveCart(items: CartItem[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch {
    /* ignore */
  }
}

export function useCart() {
  const [items, setItems] = useState<CartItem[]>(() => loadCart());

  useEffect(() => {
    saveCart(items);
  }, [items]);

  const addItem = useCallback((productId: string, size: BottleSize = 100, quantity = 1) => {
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.productId === productId && i.size === 100);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], quantity: next[idx].quantity + quantity };
        return next;
      }
      return [...prev, { productId, size: 100, quantity }];
    });
  }, []);

  const removeItem = useCallback((productId: string, _size?: BottleSize) => {
    setItems((prev) => prev.filter((i) => i.productId !== productId));
  }, []);

  const updateQuantity = useCallback((productId: string, _size: BottleSize, quantity: number) => {
    setItems((prev) => {
      if (quantity <= 0) {
        return prev.filter((i) => i.productId !== productId);
      }
      return prev.map((i) =>
        i.productId === productId ? { ...i, quantity } : i
      );
    });
  }, []);

  const clearCart = useCallback(() => setItems([]), []);

  const totalItems = useMemo(
    () => items.reduce((sum, i) => sum + i.quantity, 0),
    [items]
  );

  const totalPrice = useMemo(() => {
    return items.reduce((sum, i) => {
      const p = getProductById(i.productId);
      if (!p) return sum;
      return sum + p.price100 * i.quantity;
    }, 0);
  }, [items]);

  return {
    items,
    addItem,
    removeItem,
    updateQuantity,
    clearCart,
    totalItems,
    totalPrice,
  };
}

export type CartApi = ReturnType<typeof useCart>;
