export default function About() {
  return (
    <section id="hakkimizda" className="relative section-pad bg-ink border-t border-line">
      <div className="container-page">
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-16 items-center">
          <div className="lg:col-span-5">
            <div className="relative aspect-[4/5] overflow-hidden img-frame border border-line">
              <img
                src="/images/oud-bottle.jpg"
                alt="NEXUS parfüm"
                className="absolute inset-0 h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-void via-void/10 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-7">
                <p className="font-display text-2xl tracking-[0.18em] text-cream">NEXUS</p>
                <p className="mt-1 text-[0.6875rem] tracking-[0.2em] uppercase text-cream-muted">
                  @nexus.parfume
                </p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 lg:pl-4">
            <p className="eyebrow mb-4">Hakkımızda</p>
            <h2 className="section-title text-3xl sm:text-4xl md:text-[2.75rem] max-w-lg">
              Kokunun kesişim noktası
            </h2>
            <div className="mt-5 h-px w-12 bg-gold/70" />

            <div className="mt-7 space-y-5 max-w-xl text-[0.9375rem] font-light leading-[1.8] text-cream-muted">
              <p>
                NEXUS, niş parfüm tutkunları için özenle derlenmiş bir seçkidir. Koleksiyonumuzda
                kendi imzamız olan{' '}
                <span className="text-cream font-normal">NEXUS Seçkisi</span> formüller ile Orta
                Doğu esintili{' '}
                <span className="text-cream font-normal">Arap Esintili</span> parçalar bir
                arada yer alır.
              </p>
              <p>
                Oud, amber, odunsu, çiçeksi, fresh, baharatlı, misk ve deri ailelerinde; cinsiyet,
                mevsim ve kullanım tercihinize göre filtreleyebilir, 50 ml veya 100 ml seçenekleriyle
                sipariş verebilirsiniz.
              </p>
              <p>
                Siparişler WhatsApp üzerinden alınır. Güncel paylaşımlar için Instagram’da{' '}
                <a
                  href="https://www.instagram.com/nexus.parfume"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-cream border-b border-gold/50 hover:border-gold transition-colors"
                >
                  @nexus.parfume
                </a>{' '}
                hesabını takip edebilirsiniz.
              </p>
            </div>

            <dl className="mt-10 grid grid-cols-3 gap-4 max-w-md border-t border-line pt-8">
              {[
                { k: '18+', v: 'Formül' },
                { k: '8', v: 'Koku Ailesi' },
                { k: '2', v: 'Boyut' },
              ].map((item) => (
                <div key={item.v}>
                  <dt className="font-display text-2xl sm:text-3xl tracking-wide text-cream">
                    {item.k}
                  </dt>
                  <dd className="mt-1 text-[0.625rem] tracking-[0.16em] uppercase text-muted">
                    {item.v}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </div>
    </section>
  );
}
