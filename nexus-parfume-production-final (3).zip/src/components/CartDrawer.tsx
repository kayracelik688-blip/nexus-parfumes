import { useEffect } from 'react';
import { Minus, Plus, ShoppingBag, Trash2, X, MessageCircle } from 'lucide-react';
import { formatPrice, getProductById } from '../data/products';
import type { CartApi, BottleSize } from '../hooks/useCart';
import { buildCartWhatsAppUrl } from '../lib/whatsapp';

interface CartDrawerProps {
  open: boolean;
  onClose: () => void;
  cart: CartApi;
}

export default function CartDrawer({ open, onClose, cart }: CartDrawerProps) {
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
  }, [open, onClose]);

  if (!open) return null;

  const whatsappUrl = buildCartWhatsAppUrl(cart.items);

  return (
    <div className="fixed inset-0 z-[70]">
      <button
        type="button"
        className="absolute inset-0 bg-black/70 backdrop-blur-md"
        aria-label="Sepeti kapat"
        onClick={onClose}
      />

      <aside
        className="absolute top-0 right-0 h-full w-full max-w-[100vw] sm:max-w-md bg-ink-soft border-l border-line shadow-2xl flex flex-col animate-drawer-in"
        role="dialog"
        aria-modal="true"
        aria-labelledby="cart-title"
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-line shrink-0">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-4 h-4 text-cream-muted" strokeWidth={1.5} />
            <h2
              id="cart-title"
              className="text-[0.75rem] tracking-[0.22em] uppercase text-cream"
            >
              Sepet
            </h2>
            {cart.totalItems > 0 && (
              <span className="text-[0.6875rem] text-muted">({cart.totalItems})</span>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-cream-muted hover:text-cream transition-colors"
            aria-label="Kapat"
          >
            <X className="w-5 h-5" strokeWidth={1.5} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto overscroll-contain px-5 py-5">
          {cart.items.length === 0 ? (
            <div className="h-full min-h-[220px] flex flex-col items-center justify-center text-center px-4">
              <ShoppingBag className="w-8 h-8 text-muted/50 mb-4" strokeWidth={1.25} />
              <p className="text-sm font-light text-cream-muted">Sepetiniz boş</p>
              <button type="button" onClick={onClose} className="btn-ghost mt-5">
                Alışverişe devam et
              </button>
            </div>
          ) : (
            <ul className="space-y-3">
              {cart.items.map((item) => {
                const p = getProductById(item.productId);
                if (!p) return null;
                const unit = item.size === 50 ? p.price50 : p.price100;
                return (
                  <li
                    key={`${item.productId}-${item.size}`}
                    className="flex gap-3.5 border border-line bg-ink-card p-3"
                  >
                    <div className="w-[4.25rem] h-[5.25rem] shrink-0 overflow-hidden img-frame border border-line">
                      <img
                        src={p.image}
                        alt={p.name}
                        className="w-full h-full object-contain object-center p-1 bg-[#f5f3ee]"
                      />
                    </div>
                    <div className="flex-1 min-w-0 flex flex-col">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="font-display text-[1.05rem] tracking-[0.04em] text-cream truncate">
                            {p.name}
                          </p>
                          <p className="text-[0.75rem] font-light text-cream-muted mt-0.5">
                            {item.size} ml · {formatPrice(unit)}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            cart.removeItem(item.productId, item.size as BottleSize)
                          }
                          className="p-1.5 text-muted hover:text-cream-soft transition-colors shrink-0"
                          aria-label="Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" strokeWidth={1.5} />
                        </button>
                      </div>

                      <div className="mt-auto pt-2.5 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-0.5 border border-line bg-ink px-1 py-0.5">
                          <button
                            type="button"
                            onClick={() =>
                              cart.updateQuantity(
                                item.productId,
                                item.size as BottleSize,
                                item.quantity - 1
                              )
                            }
                            className="p-1.5 text-cream-muted hover:text-cream"
                            aria-label="Azalt"
                          >
                            <Minus className="w-3.5 h-3.5" strokeWidth={1.5} />
                          </button>
                          <span className="w-6 text-center text-xs font-normal">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              cart.updateQuantity(
                                item.productId,
                                item.size as BottleSize,
                                item.quantity + 1
                              )
                            }
                            className="p-1.5 text-cream-muted hover:text-cream"
                            aria-label="Artır"
                          >
                            <Plus className="w-3.5 h-3.5" strokeWidth={1.5} />
                          </button>
                        </div>
                        <span className="text-sm font-normal tracking-wide text-cream">
                          {formatPrice(unit * item.quantity)}
                        </span>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {cart.items.length > 0 && (
          <div className="shrink-0 border-t border-line px-5 py-5 space-y-3.5 safe-pb bg-ink-soft">
            <div className="flex items-center justify-between">
              <span className="text-[0.6875rem] tracking-[0.16em] uppercase text-muted">
                Toplam
              </span>
              <span className="text-xl font-normal tracking-wide text-cream">
                {formatPrice(cart.totalPrice)}
              </span>
            </div>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary w-full"
            >
              <MessageCircle className="w-4 h-4" strokeWidth={1.5} />
              WhatsApp ile Sipariş Ver
            </a>
            <button
              type="button"
              onClick={cart.clearCart}
              className="w-full text-[0.6875rem] tracking-[0.12em] uppercase text-muted hover:text-cream-muted py-1 transition-colors"
            >
              Sepeti temizle
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}
