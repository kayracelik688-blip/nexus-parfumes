import { motion } from 'framer-motion';
import type { Product } from '../data/products';
import { formatPrice } from '../data/products';

interface ProductCardProps {
  product: Product;
  onOpen: (product: Product) => void;
  index?: number;
}

export default function ProductCard({ product, onOpen, index = 0 }: ProductCardProps) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-12px' }}
      transition={{
        duration: 0.35,
        delay: Math.min(index * 0.08, 0.32),
        ease: [0.22, 1, 0.36, 1],
      }}
      className="group flex flex-col h-full transition-transform duration-500 ease-out hover:-translate-y-1.5"
    >
      <button
        type="button"
        onClick={() => onOpen(product)}
        className="text-left flex flex-col h-full focus:outline-none focus-visible:ring-2 focus-visible:ring-gold/50 rounded-sm"
      >
        {/* Image */}
        <div className="relative aspect-[3/4] overflow-hidden img-frame border border-line group-hover:border-gold/50 transition-colors duration-400 bg-[#f5f3ee] group-hover:shadow-[0_0_0_1px_rgba(232,197,71,0.15)]">
          <img
            src={product.image}
            alt={`${product.brand} ${product.name}`}
            loading="lazy"
            decoding="async"
            className="absolute inset-0 h-full w-full object-contain object-center p-3 sm:p-4 transition-transform duration-500 ease-out group-hover:scale-[1.03]"
            onError={(e) => {
              e.currentTarget.src = '/images/hero-bottle.jpg';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-void/40 via-transparent to-transparent pointer-events-none" />

          <div className="absolute top-2 left-2 sm:top-3 sm:left-3 flex flex-col gap-1.5 z-10">
            <span className="inline-block bg-void/65 backdrop-blur-[3px] border border-line px-1.5 sm:px-2.5 py-0.5 sm:py-1 text-[0.5rem] sm:text-[0.5625rem] tracking-[0.14em] uppercase text-cream-soft">
              {product.category}
            </span>
            {product.bestSeller && (
              <span className="inline-block bg-gold text-void px-1.5 sm:px-2.5 py-0.5 sm:py-1 text-[0.5rem] sm:text-[0.5625rem] tracking-[0.14em] uppercase font-medium">
                Best Seller
              </span>
            )}
            {product.isNew && !product.bestSeller && (
              <span className="inline-block bg-void/80 border border-gold/50 text-gold px-1.5 sm:px-2.5 py-0.5 sm:py-1 text-[0.5rem] sm:text-[0.5625rem] tracking-[0.14em] uppercase">
                New
              </span>
            )}
            {product.isNew && product.bestSeller && (
              <span className="inline-block bg-void/80 border border-gold/50 text-gold px-1.5 sm:px-2.5 py-0.5 sm:py-1 text-[0.5rem] sm:text-[0.5625rem] tracking-[0.14em] uppercase">
                New
              </span>
            )}
          </div>

          <div className="absolute inset-x-0 bottom-0 p-2 sm:p-3.5 opacity-100 sm:opacity-0 sm:translate-y-1.5 sm:group-hover:translate-y-0 sm:group-hover:opacity-100 transition-all duration-350">
            <span className="flex items-center justify-center w-full min-h-[32px] sm:min-h-[40px] border border-cream/30 bg-void/75 backdrop-blur-[3px] text-[0.55rem] sm:text-[0.625rem] tracking-[0.16em] uppercase text-cream">
              İncele
            </span>
          </div>
        </div>

        {/* Meta */}
        <div className="flex flex-col flex-1 pt-2.5 sm:pt-4 pb-1 px-0.5">
          <p className="text-[0.5rem] sm:text-[0.625rem] tracking-[0.12em] sm:tracking-[0.16em] uppercase text-muted mb-1 truncate">
            {product.brand}
            <span className="mx-1 text-line-strong">·</span>
            {product.gender}
          </p>

          <h3 className="font-display text-[0.95rem] sm:text-[1.25rem] tracking-[0.03em] text-cream leading-snug group-hover:text-cream-soft transition-colors duration-300 line-clamp-2">
            {product.name}
          </h3>

          <p className="mt-1 sm:mt-2 text-[0.7rem] sm:text-[0.8125rem] font-light leading-relaxed text-cream-muted line-clamp-2 hidden xs:block sm:block">
            {product.shortDescription}
          </p>

          <div className="mt-auto pt-2.5 sm:pt-4 flex items-baseline justify-between gap-2 border-t border-line-soft mt-2.5 sm:mt-4">
            <div>
              <p className="text-[0.5rem] sm:text-[0.5625rem] tracking-[0.12em] uppercase text-muted mb-0.5">
                100 ml
              </p>
              <p className="text-[0.85rem] sm:text-[1rem] font-medium tracking-wide text-cream">
                {formatPrice(product.price100)}
              </p>
            </div>
            <span className="text-[0.5rem] sm:text-[0.625rem] tracking-[0.1em] uppercase text-cream-muted group-hover:text-gold transition-colors duration-300 shrink-0 text-gold/80">
              Detay →
            </span>
          </div>
        </div>
      </button>
    </motion.article>
  );
}
