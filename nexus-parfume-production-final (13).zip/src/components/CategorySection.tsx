import { motion } from 'framer-motion';
import type { Product } from '../data/products';
import ProductCard from './ProductCard';

interface CategorySectionProps {
  id: string;
  eyebrow: string;
  title: string;
  titleAccent?: string;
  products: Product[];
  onOpenProduct: (p: Product) => void;
}

export default function CategorySection({
  id,
  eyebrow,
  title,
  titleAccent,
  products: list,
  onOpenProduct,
}: CategorySectionProps) {
  if (list.length === 0) return null;

  return (
    <section
      id={id}
      className="relative section-pad border-t border-line bg-void"
      aria-labelledby={`${id}-title`}
    >
      <div className="container-page">
        <header className="mb-8 md:mb-12 max-w-xl">
          <motion.p
            className="text-[0.6875rem] tracking-[0.28em] uppercase text-gold mb-3"
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-8%' }}
            transition={{ duration: 0.35 }}
          >
            {eyebrow}
          </motion.p>
          <motion.h2
            id={`${id}-title`}
            className="section-title text-3xl sm:text-4xl md:text-[2.6rem]"
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-8%' }}
            transition={{ duration: 0.4, delay: 0.05 }}
          >
            {title}
            {titleAccent ? (
              <>
                {' '}
                <span className="text-gold italic">{titleAccent}</span>
              </>
            ) : null}
          </motion.h2>
          <motion.div
            className="mt-4 h-px w-12 bg-gold"
            initial={{ scaleX: 0, opacity: 0 }}
            whileInView={{ scaleX: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.35, delay: 0.1 }}
            style={{ transformOrigin: 'left' }}
          />
        </header>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 md:gap-6">
          {list.map((product, index) => (
            <ProductCard
              key={product.id}
              product={product}
              onOpen={onOpenProduct}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
